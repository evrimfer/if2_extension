Supplemental results for CODEML (seqf: Archaea_IF2_Thermoproteota_codons.phy  treef: Archaea_IF2_Thermoproteota_aligned.fasta.treefile2)

