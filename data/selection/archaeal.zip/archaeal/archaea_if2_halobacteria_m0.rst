Supplemental results for CODEML (seqf: Archaea_IF2_Halobacteria_Thermoplasmatota_codons.phy  treef: Archaea_IF2_Halobacteria_Thermoplasmatota_aligned.fasta.treefile2)

