Supplemental results for CODEML (seqf: Archaea_IF2_Methanobacteria_codons.phy  treef: Archaea_IF2_Methanobacteria_aligned.fasta.treefile2)

