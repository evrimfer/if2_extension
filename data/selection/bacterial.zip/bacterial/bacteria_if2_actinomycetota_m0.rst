Supplemental results for CODEML (seqf: Bacteria_IF2_Actinomycetota_codons.phy  treef: Bacteria_IF2_Actinomycetota_aligned.fasta.treefile2)

