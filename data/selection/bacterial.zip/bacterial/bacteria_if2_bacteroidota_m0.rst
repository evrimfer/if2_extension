Supplemental results for CODEML (seqf: Bacteria_IF2_Bacteroidota_codons.phy  treef: Bacteria_IF2_Bacteroidota_aligned.fasta.treefile2)

