Supplemental results for CODEML (seqf: Bacteria_IF2_Bacillota_Deinococcota_codons.phy  treef: Bacteria_IF2_Bacillota_Deinococcota_aligned.fasta.treefile2)

