
CODONML in paml version 4.9j, February 2020

----------------------------------------------
Phe F TTT | Ser S TCT | Tyr Y TAT | Cys C TGT
      TTC |       TCC |       TAC |       TGC
Leu L TTA |       TCA | *** * TAA | *** * TGA
      TTG |       TCG |       TAG | Trp W TGG
----------------------------------------------
Leu L CTT | Pro P CCT | His H CAT | Arg R CGT
      CTC |       CCC |       CAC |       CGC
      CTA |       CCA | Gln Q CAA |       CGA
      CTG |       CCG |       CAG |       CGG
----------------------------------------------
Ile I ATT | Thr T ACT | Asn N AAT | Ser S AGT
      ATC |       ACC |       AAC |       AGC
      ATA |       ACA | Lys K AAA | Arg R AGA
Met M ATG |       ACG |       AAG |       AGG
----------------------------------------------
Val V GTT | Ala A GCT | Asp D GAT | Gly G GGT
      GTC |       GCC |       GAC |       GGC
      GTA |       GCA | Glu E GAA |       GGA
      GTG |       GCG |       GAG |       GGG
----------------------------------------------
Nice code, uuh?
ns = 27  	ls = 3981
Reading sequences, sequential format..
Reading seq # 1: GCA_029953635.1_Bacteria_Cyanobacteriota_Halotia_branconii_CENA392       Reading seq # 2: GCA_020521235.1_Bacteria_Cyanobacteriota_Microseira_wollei_NIES_4236       Reading seq # 3: GCA_009268125.1_Bacteria_Chloroflexota_Chloroflexia_bacterium_SDU3_3       Reading seq # 4: GCA_003991905.1_Bacteria_Cyanobacteriota_Dulcicalothrix_desertica_PCC_7102       Reading seq # 5: GCA_003991895.1_Bacteria_Cyanobacteriota_Chroococcidiopsis_cubana_SAG_39.79       Reading seq # 6: GCA_003838195.1_Bacteria_Cyanobacteriota_Okeania_hirsuta       Reading seq # 7: GCA_003003795.1_Bacteria_Cyanobacteriota_Stenomitos_frigidus_ULC18       Reading seq # 8: GCA_002368095.1_Bacteria_Cyanobacteriota_Calothrix_parasitica_NIES_267       Reading seq # 9: GCA_002368015.1_Bacteria_Cyanobacteriota_Trichormus_variabilis_NIES_23       Reading seq #10: GCA_002367995.1_Bacteria_Cyanobacteriota_Calothrix_brevissima_NIES_22       Reading seq #11: GCA_002289455.1_Bacteria_Cyanobacteriota_Calothrix_elsteri_CCALA_953       Reading seq #12: GCA_001904725.1_Bacteria_Cyanobacteriota_Phormidium_ambiguum_IAM_M_71       Reading seq #13: GCA_001904715.1_Bacteria_Cyanobacteriota_Nostoc_calcicola_FACHB_389       Reading seq #14: GCA_001306135.1_Bacteria_Chloroflexota_Herpetosiphon_geysericola       Reading seq #15: GCA_001275395.1_Bacteria_Cyanobacteriota_Hapalosiphon_sp._MRB220       Reading seq #16: GCA_000828085.3_Bacteria_Cyanobacteriota_Scytonema_tolypothrichoides_VB_61278       Reading seq #17: GCA_000828075.3_Bacteria_Cyanobacteriota_Tolypothrix_campylonemoides_VB511288       Reading seq #18: GCA_000760695.4_Bacteria_Cyanobacteriota_Tolypothrix_bouteillei_VB521301       Reading seq #19: GCA_000346485.2_Bacteria_Cyanobacteriota_Scytonema_hofmannii_PCC_7110       Reading seq #20: GCA_000317695.1_Bacteria_Cyanobacteriota_Anabaena_cylindrica_PCC_7122       Reading seq #21: GCA_000317535.1_Bacteria_Cyanobacteriota_Cylindrospermum_stagnale_PCC_7417       Reading seq #22: GCA_000317515.1_Bacteria_Cyanobacteriota_Allocoleopsis_franciscana_PCC_7113       Reading seq #23: GCA_000317145.1_Bacteria_Cyanobacteriota_Chamaesiphon_minutus_PCC_6605       Reading seq #24: GCA_000317105.1_Bacteria_Cyanobacteriota_Oscillatoria_acuminata_PCC_6304       Reading seq #25: GCA_000316115.1_Bacteria_Cyanobacteriota_Leptolyngbya_sp._PCC_7375       Reading seq #26: GCA_000196515.1_Bacteria_Cyanobacteriota_Nostoc_azollae_0708       Reading seq #27: GCA_000147335.1_Bacteria_Cyanobacteriota_Gloeothece_verrucosa_PCC_7822       
Sequences read..
Counting site patterns..  0:00
Compressing,   1296 patterns at   1327 /   1327 sites (100.0%),  0:00
Collecting fpatt[] & pose[],   1296 patterns at   1327 /   1327 sites (100.0%),  0:00
1 ambiguous codons are seen in the data:
 ---
Counting codons..

     2808 bytes for distance
  1264896 bytes for conP
    31104 bytes for fhK
  5000000 bytes for space

TREE #  1
(1, ((((2, 12), (((((3, 14), 27), (22, 23)), ((6, 25), 24)), 7)), 5), ((((4, 11), 8), 15), ((16, 17), (18, 19)))), ((9, (13, ((20, 26), 21))), 10));   MP score: -1
 15811200 bytes for conP, adjusted

1 node(s) used for scaling (Yang 2000 J Mol Evol 51:423-432):
 29

initial w for M2:NSpselection reset.

    0.035545    0.075676    0.059071    0.068101    0.107174    0.017429    0.034331    0.057508    0.031458    0.102060    0.034149    0.047924    0.107144    0.082208    0.067316    0.072700    0.030408    0.100446    0.057703    0.106617    0.056396    0.016279    0.020593    0.063347    0.107151    0.017415    0.090875    0.098273    0.055619    0.101255    0.020280    0.040130    0.090413    0.087532    0.035843    0.049881    0.041024    0.098040    0.026790    0.080281    0.018172    0.014395    0.102026    0.084564    0.098982    0.099757    0.035418    0.097690    0.061671    0.045450    0.091053    1.000000    1.585771    0.297148    0.373725    2.467823

ntime & nrate & np:    51     3    56

Bounds (np=56):
   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000100 -99.000000 -99.000000   0.000001   1.000000
  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000 999.000000  99.000000  99.000000   1.000000 999.000000
Qfactor_NS = 7.397479

np =    56
lnL0 = -81601.037114

Iterating by ming2
Initial: fx= 81601.037114
x=  0.03554  0.07568  0.05907  0.06810  0.10717  0.01743  0.03433  0.05751  0.03146  0.10206  0.03415  0.04792  0.10714  0.08221  0.06732  0.07270  0.03041  0.10045  0.05770  0.10662  0.05640  0.01628  0.02059  0.06335  0.10715  0.01742  0.09088  0.09827  0.05562  0.10126  0.02028  0.04013  0.09041  0.08753  0.03584  0.04988  0.04102  0.09804  0.02679  0.08028  0.01817  0.01440  0.10203  0.08456  0.09898  0.09976  0.03542  0.09769  0.06167  0.04545  0.09105  1.00000  1.58577  0.29715  0.37373  2.46782

  1 h-m-p  0.0000 0.0001 56003.0936 +
    0.310313    0.135386    0.221601    0.175683    0.201545    1.107846    0.786603    0.197882    0.248935    0.194304    0.282548    0.447034    0.243196    0.302998    0.401004    0.217554    0.693214    0.418131    0.269584    0.316978    0.697831    1.442677    0.959931    0.487125    0.274846    0.109989    0.129561    0.166187    0.278243    0.299571    0.762097    0.580876    0.222637    0.116958    0.173493    0.194162    0.215988    0.194731    0.135969    0.087784    0.155144    0.124581    0.221929    0.081636    0.148722    0.091647    0.147145    0.140338    0.197476    0.170220    0.215117    1.073724    1.712267    0.270735    0.000001    2.481268

fx_r: h = 748  r = 1 fhK = -1.55615e+14 
    0.310313    0.135386    0.221601    0.175683    0.201545    1.107846    0.786603    0.197882    0.248935    0.194304    0.282548    0.447034    0.243196    0.302998    0.401004    0.217554    0.693214    0.418131    0.269584    0.316978    0.697831    1.442677    0.959931    0.487125    0.274846    0.109989    0.129561    0.166187    0.278243    0.299571    0.762097    0.580876    0.222637    0.116958    0.173493    0.194162    0.215988    0.194731    0.135969    0.087784    0.155144    0.124581    0.221929    0.081636    0.148722    0.091647    0.147145    0.140338    0.197476    0.170220    0.215117    1.073724    1.712267    0.270735    0.000001    2.481268

fx_r: h = 1202  r = 1 fhK = -2.99094e+30 CYYCYCCCC 63478.825590  8 0.0000    75 | 0/56
  2 h-m-p  0.0000 0.0001 9442.9172 YYCCC 63253.110324  4 0.0000   140 | 0/56
  3 h-m-p  0.0000 0.0004 3812.5097 +++   60996.599272  m 0.0004   200 | 0/56
  4 h-m-p  0.0001 0.0005 1828.2244 +YCCC 60807.540531  3 0.0003   265 | 0/56
  5 h-m-p  0.0000 0.0002 1283.0589 ++    60644.679241  m 0.0002   324 | 0/56
  6 h-m-p  0.0000 0.0000 1821.0239 
h-m-p:      1.84203194e-20      9.21015972e-20      1.82102386e+03 60644.679241
..  | 0/56
  7 h-m-p  0.0000 0.0000 3316.6603 CCCCC 60588.749306  4 0.0000   447 | 0/56
  8 h-m-p  0.0000 0.0003 1279.0323 ++    60410.360778  m 0.0003   506 | 0/56
  9 h-m-p  0.0000 0.0002 1134.1555 ++    60311.037414  m 0.0002   565 | 0/56
 10 h-m-p  0.0001 0.0005 2797.5261 +CCYC 60076.207934  3 0.0003   630 | 0/56
 11 h-m-p  0.0001 0.0003 4064.3250 YCCC  59965.318944  3 0.0001   694 | 0/56
 12 h-m-p  0.0001 0.0003 1930.4716 ++    59838.217917  m 0.0003   753 | 0/56
 13 h-m-p  0.0000 0.0002 5265.0295 CYCCC 59824.258760  4 0.0000   820 | 0/56
 14 h-m-p  0.0001 0.0006 694.4041 +YCYC 59753.796559  3 0.0005   884 | 0/56
 15 h-m-p  0.0001 0.0005 1117.6676 ++    59646.376955  m 0.0005   943 | 1/56
 16 h-m-p  0.0002 0.0009 914.4039 YCCC  59616.916344  3 0.0003  1007 | 1/56
 17 h-m-p  0.0007 0.0037 314.8237 CCC   59595.290310  2 0.0008  1070 | 1/56
 18 h-m-p  0.0007 0.0033 217.8163 CCC   59587.805424  2 0.0006  1133 | 1/56
 19 h-m-p  0.0007 0.0040 194.8517 YCC   59577.072948  2 0.0012  1195 | 1/56
 20 h-m-p  0.0010 0.0051 174.1709 CCC   59569.656181  2 0.0012  1258 | 1/56
 21 h-m-p  0.0008 0.0046 247.7477 CCC   59559.400794  2 0.0013  1321 | 1/56
 22 h-m-p  0.0012 0.0061 209.1477 CCC   59551.147660  2 0.0013  1384 | 1/56
 23 h-m-p  0.0012 0.0157 224.4095 YCCC  59546.662208  3 0.0008  1448 | 1/56
 24 h-m-p  0.0009 0.0113 194.6149 CC    59540.340617  1 0.0013  1509 | 1/56
 25 h-m-p  0.0019 0.0188 135.4267 CC    59534.254815  1 0.0020  1570 | 1/56
 26 h-m-p  0.0010 0.0050 257.2085 CCC   59526.867262  2 0.0013  1633 | 1/56
 27 h-m-p  0.0025 0.0126 129.4335 YC    59522.876137  1 0.0016  1693 | 1/56
 28 h-m-p  0.0014 0.0138 150.8730 CC    59518.993892  1 0.0014  1754 | 1/56
 29 h-m-p  0.0015 0.0076 121.5308 CCC   59515.072336  2 0.0018  1817 | 1/56
 30 h-m-p  0.0016 0.0154 139.2993 CC    59510.912127  1 0.0018  1878 | 1/56
 31 h-m-p  0.0028 0.0154  91.2214 YC    59508.729986  1 0.0016  1938 | 1/56
 32 h-m-p  0.0021 0.0154  68.9918 YC    59507.312060  1 0.0015  1998 | 1/56
 33 h-m-p  0.0017 0.0208  58.5499 CC    59505.737966  1 0.0021  2059 | 1/56
 34 h-m-p  0.0032 0.0220  37.4275 C     59504.209922  0 0.0032  2118 | 1/56
 35 h-m-p  0.0028 0.0192  42.8354 YC    59502.958059  1 0.0023  2178 | 1/56
 36 h-m-p  0.0018 0.0218  54.1234 CC    59501.739219  1 0.0017  2239 | 1/56
 37 h-m-p  0.0017 0.0205  53.2165 CC    59500.521794  1 0.0016  2300 | 1/56
 38 h-m-p  0.0024 0.0218  35.5631 CC    59498.566177  1 0.0033  2361 | 1/56
 39 h-m-p  0.0023 0.0236  51.1645 YC    59493.640350  1 0.0053  2421 | 1/56
 40 h-m-p  0.0049 0.0243  53.1855 YCC   59490.979431  2 0.0027  2483 | 1/56
 41 h-m-p  0.0016 0.0115  86.9505 CC    59488.019644  1 0.0018  2544 | 1/56
 42 h-m-p  0.0058 0.0576  27.2513 CC    59484.254585  1 0.0077  2605 | 1/56
 43 h-m-p  0.0043 0.0390  48.5487 YC    59481.615505  1 0.0032  2665 | 1/56
 44 h-m-p  0.0044 0.0456  34.6386 CC    59479.396755  1 0.0037  2726 | 1/56
 45 h-m-p  0.0034 0.0443  38.0616 YC    59473.388905  1 0.0082  2786 | 1/56
 46 h-m-p  0.0060 0.0322  51.5633 CCC   59467.725934  2 0.0056  2849 | 1/56
 47 h-m-p  0.0080 0.0433  36.2969 CYC   59461.888928  2 0.0077  2911 | 1/56
 48 h-m-p  0.0055 0.0469  50.6097 YCC   59451.727199  2 0.0103  2973 | 1/56
 49 h-m-p  0.0097 0.0483  33.5368 CCC   59446.329560  2 0.0108  3036 | 1/56
 50 h-m-p  0.0063 0.0314  23.8236 CCC   59444.503893  2 0.0075  3099 | 1/56
 51 h-m-p  0.0124 0.0852  14.3180 CC    59442.695690  1 0.0162  3160 | 1/56
 52 h-m-p  0.0115 0.0627  20.1639 CYC   59441.074358  2 0.0106  3222 | 1/56
 53 h-m-p  0.0205 0.2905  10.4045 CC    59438.263762  1 0.0287  3283 | 1/56
 54 h-m-p  0.0084 0.0686  35.4642 YC    59432.377974  1 0.0151  3343 | 1/56
 55 h-m-p  0.0092 0.0460  46.4604 CCC   59426.241682  2 0.0104  3406 | 1/56
 56 h-m-p  0.0262 0.1420  18.4695 CY    59417.970138  1 0.0268  3467 | 1/56
 57 h-m-p  0.0139 0.0867  35.5368 CCC   59404.584114  2 0.0209  3530 | 1/56
 58 h-m-p  0.0064 0.0321  45.8408 CC    59399.739875  1 0.0068  3591 | 1/56
 59 h-m-p  0.0099 0.0497  23.9088 YCCC  59395.215956  3 0.0169  3655 | 1/56
 60 h-m-p  0.0092 0.0460  31.1651 CC    59392.823328  1 0.0092  3716 | 1/56
 61 h-m-p  0.0163 0.2328  17.4727 CCC   59390.724400  2 0.0198  3779 | 1/56
 62 h-m-p  0.0512 0.5949   6.7509 YC    59389.758419  1 0.0342  3839 | 1/56
 63 h-m-p  0.0208 0.2499  11.1231 CC    59388.289750  1 0.0307  3900 | 1/56
 64 h-m-p  0.1251 2.3446   2.7261 +YC   59379.223291  1 0.3869  3961 | 1/56
 65 h-m-p  0.0427 0.2133  12.4409 CCC   59374.145693  2 0.0595  4024 | 1/56
 66 h-m-p  1.6000 8.0000   0.3546 CYC   59370.058731  2 1.7704  4086 | 1/56
 67 h-m-p  1.2233 8.0000   0.5132 CYC   59368.576659  2 1.1768  4203 | 1/56
 68 h-m-p  1.6000 8.0000   0.1801 CC    59368.064164  1 1.3890  4319 | 1/56
 69 h-m-p  1.6000 8.0000   0.1251 CC    59367.748370  1 2.1390  4435 | 1/56
 70 h-m-p  1.6000 8.0000   0.0409 CC    59367.592151  1 2.2843  4551 | 1/56
 71 h-m-p  1.6000 8.0000   0.0199 CC    59367.547906  1 2.0836  4667 | 1/56
 72 h-m-p  1.6000 8.0000   0.0205 YC    59367.515988  1 2.6171  4782 | 1/56
 73 h-m-p  1.6000 8.0000   0.0240 CC    59367.493959  1 2.2368  4898 | 1/56
 74 h-m-p  1.6000 8.0000   0.0117 C     59367.486411  0 2.1798  5012 | 1/56
 75 h-m-p  1.6000 8.0000   0.0044 C     59367.485411  0 1.5757  5126 | 1/56
 76 h-m-p  1.6000 8.0000   0.0008 C     59367.485342  0 1.4260  5240 | 1/56
 77 h-m-p  1.6000 8.0000   0.0004 C     59367.485334  0 1.5003  5354 | 1/56
 78 h-m-p  1.6000 8.0000   0.0001 C     59367.485332  0 2.1968  5468 | 1/56
 79 h-m-p  1.6000 8.0000   0.0001 C     59367.485332  0 1.7766  5582 | 1/56
 80 h-m-p  1.6000 8.0000   0.0000 C     59367.485332  0 1.6000  5696 | 1/56
 81 h-m-p  1.6000 8.0000   0.0000 C     59367.485332  0 1.6000  5810 | 1/56
 82 h-m-p  1.6000 8.0000   0.0000 --C   59367.485332  0 0.0250  5926
Out..
lnL  = -59367.485332
5927 lfun, 23708 eigenQcodon, 906831 P(t)

BEBing (dim = 4).  This may take several minutes.
Calculating f(x_h|w): 10 categories 21 w sets.
Calculating f(X), the marginal likelihood.
	log(fX) = -59401.880645  S = -57206.923121 -2207.719502
Calculating f(w|X), posterior probabilities of site classes.
	did  10 / 1296 patterns  30:56	did  20 / 1296 patterns  30:56	did  30 / 1296 patterns  30:56	did  40 / 1296 patterns  30:56	did  50 / 1296 patterns  30:56	did  60 / 1296 patterns  30:56	did  70 / 1296 patterns  30:56	did  80 / 1296 patterns  30:56	did  90 / 1296 patterns  30:56	did 100 / 1296 patterns  30:56	did 110 / 1296 patterns  30:56	did 120 / 1296 patterns  30:56	did 130 / 1296 patterns  30:56	did 140 / 1296 patterns  30:56	did 150 / 1296 patterns  30:56	did 160 / 1296 patterns  30:56	did 170 / 1296 patterns  30:56	did 180 / 1296 patterns  30:56	did 190 / 1296 patterns  30:56	did 200 / 1296 patterns  30:56	did 210 / 1296 patterns  30:56	did 220 / 1296 patterns  30:56	did 230 / 1296 patterns  30:56	did 240 / 1296 patterns  30:56	did 250 / 1296 patterns  30:56	did 260 / 1296 patterns  30:56	did 270 / 1296 patterns  30:56	did 280 / 1296 patterns  30:56	did 290 / 1296 patterns  30:56	did 300 / 1296 patterns  30:56	did 310 / 1296 patterns  30:56	did 320 / 1296 patterns  30:56	did 330 / 1296 patterns  30:57	did 340 / 1296 patterns  30:57	did 350 / 1296 patterns  30:57	did 360 / 1296 patterns  30:57	did 370 / 1296 patterns  30:57	did 380 / 1296 patterns  30:57	did 390 / 1296 patterns  30:57	did 400 / 1296 patterns  30:57	did 410 / 1296 patterns  30:57	did 420 / 1296 patterns  30:57	did 430 / 1296 patterns  30:57	did 440 / 1296 patterns  30:57	did 450 / 1296 patterns  30:57	did 460 / 1296 patterns  30:57	did 470 / 1296 patterns  30:57	did 480 / 1296 patterns  30:57	did 490 / 1296 patterns  30:57	did 500 / 1296 patterns  30:57	did 510 / 1296 patterns  30:57	did 520 / 1296 patterns  30:57	did 530 / 1296 patterns  30:57	did 540 / 1296 patterns  30:57	did 550 / 1296 patterns  30:57	did 560 / 1296 patterns  30:57	did 570 / 1296 patterns  30:57	did 580 / 1296 patterns  30:57	did 590 / 1296 patterns  30:57	did 600 / 1296 patterns  30:57	did 610 / 1296 patterns  30:57	did 620 / 1296 patterns  30:57	did 630 / 1296 patterns  30:57	did 640 / 1296 patterns  30:57	did 650 / 1296 patterns  30:57	did 660 / 1296 patterns  30:57	did 670 / 1296 patterns  30:57	did 680 / 1296 patterns  30:57	did 690 / 1296 patterns  30:57	did 700 / 1296 patterns  30:58	did 710 / 1296 patterns  30:58	did 720 / 1296 patterns  30:58	did 730 / 1296 patterns  30:58	did 740 / 1296 patterns  30:58	did 750 / 1296 patterns  30:58	did 760 / 1296 patterns  30:58	did 770 / 1296 patterns  30:58	did 780 / 1296 patterns  30:58	did 790 / 1296 patterns  30:58	did 800 / 1296 patterns  30:58	did 810 / 1296 patterns  30:58	did 820 / 1296 patterns  30:58	did 830 / 1296 patterns  30:58	did 840 / 1296 patterns  30:58	did 850 / 1296 patterns  30:58	did 860 / 1296 patterns  30:58	did 870 / 1296 patterns  30:58	did 880 / 1296 patterns  30:58	did 890 / 1296 patterns  30:58	did 900 / 1296 patterns  30:58	did 910 / 1296 patterns  30:58	did 920 / 1296 patterns  30:58	did 930 / 1296 patterns  30:58	did 940 / 1296 patterns  30:58	did 950 / 1296 patterns  30:58	did 960 / 1296 patterns  30:58	did 970 / 1296 patterns  30:58	did 980 / 1296 patterns  30:58	did 990 / 1296 patterns  30:58	did 1000 / 1296 patterns  30:58	did 1010 / 1296 patterns  30:58	did 1020 / 1296 patterns  30:58	did 1030 / 1296 patterns  30:58	did 1040 / 1296 patterns  30:58	did 1050 / 1296 patterns  30:58	did 1060 / 1296 patterns  30:58	did 1070 / 1296 patterns  30:59	did 1080 / 1296 patterns  30:59	did 1090 / 1296 patterns  30:59	did 1100 / 1296 patterns  30:59	did 1110 / 1296 patterns  30:59	did 1120 / 1296 patterns  30:59	did 1130 / 1296 patterns  30:59	did 1140 / 1296 patterns  30:59	did 1150 / 1296 patterns  30:59	did 1160 / 1296 patterns  30:59	did 1170 / 1296 patterns  30:59	did 1180 / 1296 patterns  30:59	did 1190 / 1296 patterns  30:59	did 1200 / 1296 patterns  30:59	did 1210 / 1296 patterns  30:59	did 1220 / 1296 patterns  30:59	did 1230 / 1296 patterns  30:59	did 1240 / 1296 patterns  30:59	did 1250 / 1296 patterns  30:59	did 1260 / 1296 patterns  30:59	did 1270 / 1296 patterns  30:59	did 1280 / 1296 patterns  30:59	did 1290 / 1296 patterns  30:59	did 1296 / 1296 patterns  30:59end of tree file.

Time used: 30:59
