Supplemental results for CODEML (seqf: Bacteria_IF2_Pseudomonadota_codons.phy  treef: Bacteria_IF2_Pseudomonadota_aligned.fasta.treefile2)

