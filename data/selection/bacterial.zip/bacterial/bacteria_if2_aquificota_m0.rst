Supplemental results for CODEML (seqf: Bacteria_IF2_Aquificota_codons.phy  treef: Bacteria_IF2_Aquificota_aligned.fasta.treefile2)

