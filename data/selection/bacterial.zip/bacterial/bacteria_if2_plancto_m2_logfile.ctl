
CODONML in paml version 4.9j, February 2020

----------------------------------------------
Phe F TTT | Ser S TCT | Tyr Y TAT | Cys C TGT
      TTC |       TCC |       TAC |       TGC
Leu L TTA |       TCA | *** * TAA | *** * TGA
      TTG |       TCG |       TAG | Trp W TGG
----------------------------------------------
Leu L CTT | Pro P CCT | His H CAT | Arg R CGT
      CTC |       CCC |       CAC |       CGC
      CTA |       CCA | Gln Q CAA |       CGA
      CTG |       CCG |       CAG |       CGG
----------------------------------------------
Ile I ATT | Thr T ACT | Asn N AAT | Ser S AGT
      ATC |       ACC |       AAC |       AGC
      ATA |       ACA | Lys K AAA | Arg R AGA
Met M ATG |       ACG |       AAG |       AGG
----------------------------------------------
Val V GTT | Ala A GCT | Asp D GAT | Gly G GGT
      GTC |       GCC |       GAC |       GGC
      GTA |       GCA | Glu E GAA |       GGA
      GTG |       GCG |       GAG |       GGG
----------------------------------------------
Nice code, uuh?
ns = 19  	ls = 3822
Reading sequences, sequential format..
Reading seq # 1: GCA_011044495.1_Bacteria_Verrucomicrobiota_Roseimicrobium_sp._ORNL1       Reading seq # 2: GCA_009720545.1_Bacteria_Planctomycetota_Gimesia_maris       Reading seq # 3: GCA_008087625.1_Bacteria_Planctomycetota_Aquisphaera_giovannonii       Reading seq # 4: GCA_007992435.1_Bacteria_Verrucomicrobiota_Brevifollis_gellanilyticus       Reading seq # 5: GCA_007860175.1_Bacteria_Planctomycetota_Rubripirellula_reticaptiva       Reading seq # 6: GCA_007860135.1_Bacteria_Planctomycetota_Novipirellula_artificiosorum       Reading seq # 7: GCA_007860125.1_Bacteria_Planctomycetota_Rubripirellula_tenax       Reading seq # 8: GCA_007860045.1_Bacteria_Planctomycetota_Stieleria_varia       Reading seq # 9: GCA_007754155.1_Bacteria_Planctomycetota_Stieleria_neptunia       Reading seq #10: GCA_007752535.1_Bacteria_Planctomycetota_Tautonia_plasticadhaerens       Reading seq #11: GCA_007751945.1_Bacteria_Planctomycetota_Gimesia_panareensis       Reading seq #12: GCA_007751035.1_Bacteria_Planctomycetota_Lignipirellula_cremea       Reading seq #13: GCA_007747995.1_Bacteria_Planctomycetota_Symmachiella_dynata       Reading seq #14: GCA_007746795.1_Bacteria_Planctomycetota_Gimesia_algae       Reading seq #15: GCA_007744675.1_Bacteria_Planctomycetota_Gimesia_alba       Reading seq #16: GCA_007741535.1_Bacteria_Planctomycetota_Rubripirellula_lacrimiformis       Reading seq #17: GCA_002727185.1_Bacteria_Planctomycetota_Rhodopirellula_bahusiensis       Reading seq #18: GCA_001650175.1_Bacteria_Verrucomicrobiota_Termitidicoccus_mucosus       Reading seq #19: GCA_000172555.1_Bacteria_Verrucomicrobiota_Pedosphaera_parvula_Ellin514       
Sequences read..
Counting site patterns..  0:00
Compressing,   1219 patterns at   1274 /   1274 sites (100.0%),  0:00
Collecting fpatt[] & pose[],   1219 patterns at   1274 /   1274 sites (100.0%),  0:00
1 ambiguous codons are seen in the data:
 ---
Counting codons..

     1368 bytes for distance
  1189744 bytes for conP
    29256 bytes for fhK
  5000000 bytes for space

TREE #  1
(1, ((((((((2, 14), 15), 11), 13), ((((5, 7), 16), ((6, (8, 9)), 17)), 12)), (3, 10)), 18), 19), 4);   MP score: -1
 10112824 bytes for conP, adjusted

1 node(s) used for scaling (Yang 2000 J Mol Evol 51:423-432):
 22

initial w for M2:NSpselection reset.

    0.043136    0.085927    0.106843    0.056114    0.058275    0.092779    0.071807    0.064179    0.089010    0.064860    0.016969    0.072460    0.050573    0.079853    0.071981    0.095148    0.090142    0.058999    0.029640    0.012950    0.029975    0.057911    0.092487    0.012095    0.081149    0.106509    0.064235    0.087309    0.045094    0.021511    0.090703    0.069688    0.095103    0.089931    0.029950    1.000000    0.854134    0.575067    0.447965    2.562431

ntime & nrate & np:    35     3    40

Bounds (np=40):
   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000004   0.000100 -99.000000 -99.000000   0.000001   1.000000
  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000  50.000000 999.000000  99.000000  99.000000   1.000000 999.000000
Qfactor_NS = 5.651752

np =    40
lnL0 = -60464.363156

Iterating by ming2
Initial: fx= 60464.363156
x=  0.04314  0.08593  0.10684  0.05611  0.05827  0.09278  0.07181  0.06418  0.08901  0.06486  0.01697  0.07246  0.05057  0.07985  0.07198  0.09515  0.09014  0.05900  0.02964  0.01295  0.02997  0.05791  0.09249  0.01209  0.08115  0.10651  0.06424  0.08731  0.04509  0.02151  0.09070  0.06969  0.09510  0.08993  0.02995  1.00000  0.85413  0.57507  0.44796  2.56243

  1 h-m-p  0.0000 0.0001 39889.7759 +YCYYYCCC 47295.396622  7 0.0001    56 | 0/40
  2 h-m-p  0.0000 0.0002 4232.8111 YYCCC 47155.194039  4 0.0000   105 | 0/40
  3 h-m-p  0.0001 0.0021 1521.6684 +++   45671.264591  m 0.0021   149 | 0/40
  4 h-m-p  0.0005 0.0027 1588.5848 YCYCCC 45563.752557  5 0.0002   200 | 0/40
  5 h-m-p  0.0006 0.0032 585.8223 +CYCC 45283.970058  3 0.0023   249 | 0/40
  6 h-m-p  0.0012 0.0062 480.0044 CCCCC 45160.569238  4 0.0017   300 | 0/40
  7 h-m-p  0.0018 0.0089 182.3430 CCCC  45132.195918  3 0.0022   349 | 0/40
  8 h-m-p  0.0034 0.0178 118.9022 CCC   45118.092880  2 0.0029   396 | 0/40
  9 h-m-p  0.0042 0.0230  80.2770 CCCC  45104.349639  3 0.0059   445 | 0/40
 10 h-m-p  0.0027 0.0144 174.6703 CCC   45088.967117  2 0.0034   492 | 0/40
 11 h-m-p  0.0031 0.0156 156.1657 CYC   45076.597921  2 0.0035   538 | 0/40
 12 h-m-p  0.0029 0.0143 170.1542 CCC   45064.498466  2 0.0032   585 | 0/40
 13 h-m-p  0.0030 0.0149 140.8709 YCCC  45046.247765  3 0.0061   633 | 0/40
 14 h-m-p  0.0018 0.0091 189.7450 YCCC  45031.758869  3 0.0037   681 | 0/40
 15 h-m-p  0.0047 0.0293 147.5362 CCC   45014.758113  2 0.0058   728 | 0/40
 16 h-m-p  0.0048 0.0337 179.2049 YCCC  44977.342229  3 0.0103   776 | 0/40
 17 h-m-p  0.0054 0.0271 312.6323 CCC   44936.162450  2 0.0067   823 | 0/40
 18 h-m-p  0.0044 0.0221 210.1123 CCC   44908.905546  2 0.0066   870 | 0/40
 19 h-m-p  0.0037 0.0184 145.1628 YC    44884.597483  1 0.0086   914 | 0/40
 20 h-m-p  0.0033 0.0163 126.7544 CCC   44871.874957  2 0.0052   961 | 0/40
 21 h-m-p  0.0044 0.0222  65.1726 CCC   44864.619928  2 0.0057  1008 | 0/40
 22 h-m-p  0.0071 0.0663  52.3024 CCC   44858.526188  2 0.0059  1055 | 0/40
 23 h-m-p  0.0092 0.0698  33.4565 YCCC  44841.877656  3 0.0200  1103 | 0/40
 24 h-m-p  0.0052 0.0261  57.1945 CCC   44831.788359  2 0.0064  1150 | 0/40
 25 h-m-p  0.0089 0.0458  41.1251 YC    44811.603078  1 0.0155  1194 | 0/40
 26 h-m-p  0.0083 0.0416  65.6630 CCCC  44793.341440  3 0.0092  1243 | 0/40
 27 h-m-p  0.0090 0.0448  61.2730 YCCC  44784.340600  3 0.0062  1291 | 0/40
 28 h-m-p  0.0162 0.0896  23.6597 CC    44778.522128  1 0.0200  1336 | 0/40
 29 h-m-p  0.0192 0.0960  14.2705 CCC   44776.015195  2 0.0244  1383 | 0/40
 30 h-m-p  0.0363 0.1815   9.0551 CC    44774.286090  1 0.0295  1428 | 0/40
 31 h-m-p  0.0311 0.1879   8.5952 CCC   44770.520925  2 0.0495  1475 | 0/40
 32 h-m-p  0.0217 0.1114  19.6488 CCC   44764.415988  2 0.0299  1522 | 0/40
 33 h-m-p  0.0191 0.0953  25.3994 CCC   44758.354836  2 0.0244  1569 | 0/40
 34 h-m-p  0.0464 0.2319  13.3664 YC    44756.410998  1 0.0241  1613 | 0/40
 35 h-m-p  0.0796 0.7297   4.0459 CC    44756.127624  1 0.0261  1658 | 0/40
 36 h-m-p  0.0511 1.7428   2.0671 YC    44755.583001  1 0.0896  1702 | 0/40
 37 h-m-p  0.0398 2.5020   4.6487 +CYC  44752.687964  2 0.1673  1749 | 0/40
 38 h-m-p  0.0745 0.5132  10.4387 YC    44751.753701  1 0.0304  1793 | 0/40
 39 h-m-p  0.1105 1.0392   2.8685 YC    44751.515158  1 0.0502  1837 | 0/40
 40 h-m-p  0.0998 4.0361   1.4446 +CC   44749.983613  1 0.4803  1883 | 0/40
 41 h-m-p  0.0645 0.4830  10.7539 CYC   44748.630908  2 0.0580  1929 | 0/40
 42 h-m-p  1.1630 8.0000   0.5363 YC    44747.736593  1 0.8309  1973 | 0/40
 43 h-m-p  0.0815 1.5772   5.4700 CC    44746.972463  1 0.0695  2058 | 0/40
 44 h-m-p  0.1446 2.0260   2.6303 YC    44746.785135  1 0.0587  2102 | 0/40
 45 h-m-p  0.3771 8.0000   0.4095 +CC   44745.930290  1 1.2847  2148 | 0/40
 46 h-m-p  0.0652 1.1285   8.0617 CC    44744.791901  1 0.0845  2233 | 0/40
 47 h-m-p  0.9200 8.0000   0.7402 +YC   44738.668931  1 5.3181  2278 | 0/40
 48 h-m-p  1.5704 8.0000   2.5066 YCCC  44728.360322  3 2.9825  2366 | 0/40
 49 h-m-p  1.3431 8.0000   5.5663 +YCCC 44710.127946  3 4.0115  2415 | 0/40
 50 h-m-p  1.6000 8.0000   6.8070 CCC   44703.327898  2 1.9948  2462 | 0/40
 51 h-m-p  1.6000 8.0000   3.0037 YC    44702.359738  1 0.8292  2506 | 0/40
 52 h-m-p  0.5389 8.0000   4.6216 YC    44701.727331  1 1.1612  2550 | 0/40
 53 h-m-p  1.6000 8.0000   0.9754 CY    44701.636499  1 1.7404  2595 | 0/40
 54 h-m-p  1.6000 8.0000   0.3733 C     44701.619520  0 1.6668  2678 | 0/40
 55 h-m-p  1.6000 8.0000   0.1497 C     44701.615021  0 2.0032  2761 | 0/40
 56 h-m-p  1.6000 8.0000   0.0259 C     44701.614090  0 2.0273  2844 | 0/40
 57 h-m-p  1.6000 8.0000   0.0108 C     44701.613938  0 1.4717  2927 | 0/40
 58 h-m-p  1.2569 8.0000   0.0126 C     44701.613912  0 1.8839  3010 | 0/40
 59 h-m-p  1.6000 8.0000   0.0012 C     44701.613909  0 2.0532  3093 | 0/40
 60 h-m-p  1.6000 8.0000   0.0005 C     44701.613908  0 1.9206  3176 | 0/40
 61 h-m-p  1.6000 8.0000   0.0000 C     44701.613908  0 1.9492  3259 | 0/40
 62 h-m-p  0.6964 8.0000   0.0001 Y     44701.613908  0 1.4915  3342 | 0/40
 63 h-m-p  1.6000 8.0000   0.0000 C     44701.613908  0 1.6000  3425 | 0/40
 64 h-m-p  1.6000 8.0000   0.0000 C     44701.613908  0 1.9966  3508 | 0/40
 65 h-m-p  1.6000 8.0000   0.0000 Y     44701.613908  0 1.6000  3591 | 0/40
 66 h-m-p  0.5860 8.0000   0.0000 ------------Y 44701.613908  0 0.0000  3686
Out..
lnL  = -44701.613908
3687 lfun, 14748 eigenQcodon, 387135 P(t)

BEBing (dim = 4).  This may take several minutes.
Calculating f(x_h|w): 10 categories 21 w sets.
Calculating f(X), the marginal likelihood.
	log(fX) = -44814.941085  S = -43035.133593 -1789.060874
Calculating f(w|X), posterior probabilities of site classes.
	did  10 / 1219 patterns  14:59	did  20 / 1219 patterns  14:59	did  30 / 1219 patterns  14:59	did  40 / 1219 patterns  14:59	did  50 / 1219 patterns  14:59	did  60 / 1219 patterns  14:59	did  70 / 1219 patterns  14:59	did  80 / 1219 patterns  15:00	did  90 / 1219 patterns  15:00	did 100 / 1219 patterns  15:00	did 110 / 1219 patterns  15:00	did 120 / 1219 patterns  15:00	did 130 / 1219 patterns  15:00	did 140 / 1219 patterns  15:00	did 150 / 1219 patterns  15:00	did 160 / 1219 patterns  15:00	did 170 / 1219 patterns  15:00	did 180 / 1219 patterns  15:00	did 190 / 1219 patterns  15:00	did 200 / 1219 patterns  15:00	did 210 / 1219 patterns  15:00	did 220 / 1219 patterns  15:00	did 230 / 1219 patterns  15:00	did 240 / 1219 patterns  15:00	did 250 / 1219 patterns  15:00	did 260 / 1219 patterns  15:00	did 270 / 1219 patterns  15:00	did 280 / 1219 patterns  15:00	did 290 / 1219 patterns  15:00	did 300 / 1219 patterns  15:00	did 310 / 1219 patterns  15:00	did 320 / 1219 patterns  15:00	did 330 / 1219 patterns  15:00	did 340 / 1219 patterns  15:00	did 350 / 1219 patterns  15:00	did 360 / 1219 patterns  15:00	did 370 / 1219 patterns  15:01	did 380 / 1219 patterns  15:01	did 390 / 1219 patterns  15:01	did 400 / 1219 patterns  15:01	did 410 / 1219 patterns  15:01	did 420 / 1219 patterns  15:01	did 430 / 1219 patterns  15:01	did 440 / 1219 patterns  15:01	did 450 / 1219 patterns  15:01	did 460 / 1219 patterns  15:01	did 470 / 1219 patterns  15:01	did 480 / 1219 patterns  15:01	did 490 / 1219 patterns  15:01	did 500 / 1219 patterns  15:01	did 510 / 1219 patterns  15:01	did 520 / 1219 patterns  15:01	did 530 / 1219 patterns  15:01	did 540 / 1219 patterns  15:01	did 550 / 1219 patterns  15:01	did 560 / 1219 patterns  15:01	did 570 / 1219 patterns  15:01	did 580 / 1219 patterns  15:01	did 590 / 1219 patterns  15:01	did 600 / 1219 patterns  15:01	did 610 / 1219 patterns  15:01	did 620 / 1219 patterns  15:01	did 630 / 1219 patterns  15:01	did 640 / 1219 patterns  15:01	did 650 / 1219 patterns  15:01	did 660 / 1219 patterns  15:01	did 670 / 1219 patterns  15:01	did 680 / 1219 patterns  15:02	did 690 / 1219 patterns  15:02	did 700 / 1219 patterns  15:02	did 710 / 1219 patterns  15:02	did 720 / 1219 patterns  15:02	did 730 / 1219 patterns  15:02	did 740 / 1219 patterns  15:02	did 750 / 1219 patterns  15:02	did 760 / 1219 patterns  15:02	did 770 / 1219 patterns  15:02	did 780 / 1219 patterns  15:02	did 790 / 1219 patterns  15:02	did 800 / 1219 patterns  15:02	did 810 / 1219 patterns  15:02	did 820 / 1219 patterns  15:02	did 830 / 1219 patterns  15:02	did 840 / 1219 patterns  15:02	did 850 / 1219 patterns  15:02	did 860 / 1219 patterns  15:02	did 870 / 1219 patterns  15:02	did 880 / 1219 patterns  15:02	did 890 / 1219 patterns  15:02	did 900 / 1219 patterns  15:02	did 910 / 1219 patterns  15:02	did 920 / 1219 patterns  15:02	did 930 / 1219 patterns  15:02	did 940 / 1219 patterns  15:02	did 950 / 1219 patterns  15:02	did 960 / 1219 patterns  15:02	did 970 / 1219 patterns  15:02	did 980 / 1219 patterns  15:03	did 990 / 1219 patterns  15:03	did 1000 / 1219 patterns  15:03	did 1010 / 1219 patterns  15:03	did 1020 / 1219 patterns  15:03	did 1030 / 1219 patterns  15:03	did 1040 / 1219 patterns  15:03	did 1050 / 1219 patterns  15:03	did 1060 / 1219 patterns  15:03	did 1070 / 1219 patterns  15:03	did 1080 / 1219 patterns  15:03	did 1090 / 1219 patterns  15:03	did 1100 / 1219 patterns  15:03	did 1110 / 1219 patterns  15:03	did 1120 / 1219 patterns  15:03	did 1130 / 1219 patterns  15:03	did 1140 / 1219 patterns  15:03	did 1150 / 1219 patterns  15:03	did 1160 / 1219 patterns  15:03	did 1170 / 1219 patterns  15:03	did 1180 / 1219 patterns  15:03	did 1190 / 1219 patterns  15:03	did 1200 / 1219 patterns  15:03	did 1210 / 1219 patterns  15:03	did 1219 / 1219 patterns  15:03end of tree file.

Time used: 15:04
