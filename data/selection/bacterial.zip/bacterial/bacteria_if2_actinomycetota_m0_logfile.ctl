
CODONML in paml version 4.9j, February 2020

----------------------------------------------
Phe F TTT | Ser S TCT | Tyr Y TAT | Cys C TGT
      TTC |       TCC |       TAC |       TGC
Leu L TTA |       TCA | *** * TAA | *** * TGA
      TTG |       TCG |       TAG | Trp W TGG
----------------------------------------------
Leu L CTT | Pro P CCT | His H CAT | Arg R CGT
      CTC |       CCC |       CAC |       CGC
      CTA |       CCA | Gln Q CAA |       CGA
      CTG |       CCG |       CAG |       CGG
----------------------------------------------
Ile I ATT | Thr T ACT | Asn N AAT | Ser S AGT
      ATC |       ACC |       AAC |       AGC
      ATA |       ACA | Lys K AAA | Arg R AGA
Met M ATG |       ACG |       AAG |       AGG
----------------------------------------------
Val V GTT | Ala A GCT | Asp D GAT | Gly G GGT
      GTC |       GCC |       GAC |       GGC
      GTA |       GCA | Glu E GAA |       GGA
      GTG |       GCG |       GAG |       GGG
----------------------------------------------
Nice code, uuh?
ns = 165  	ls = 6141
Reading sequences, sequential format..
Reading seq # 1: GCA_900188445.1_Bacteria_Actinomycetota_Actinomadura_meyerae       Reading seq # 2: GCA_900188405.1_Bacteria_Actinomycetota_Actinacidiphila_glaucinigra       Reading seq # 3: GCA_900143005.1_Bacteria_Actinomycetota_Cryptosporangium_aurantiacum       Reading seq # 4: GCA_900129375.1_Bacteria_Actinomycetota_Streptoalloteichus_hindustanus       Reading seq # 5: GCA_900119165.1_Bacteria_Actinomycetota_Amycolatopsis_australiensis       Reading seq # 6: GCA_900115005.1_Bacteria_Actinomycetota_Pseudonocardia_ammonioxydans       Reading seq # 7: GCA_900114035.1_Bacteria_Actinomycetota_Amycolatopsis_sacchari       Reading seq # 8: GCA_900111885.1_Bacteria_Actinomycetota_Amycolatopsis_marina       Reading seq # 9: GCA_900110575.1_Bacteria_Actinomycetota_Amycolatopsis_saalfeldensis       Reading seq #10: GCA_900108175.1_Bacteria_Actinomycetota_Thermomonospora_echinospora       Reading seq #11: GCA_900107455.1_Bacteria_Actinomycetota_Asanoa_ishikariensis       Reading seq #12: GCA_900107045.1_Bacteria_Actinomycetota_Amycolatopsis_xylanica       Reading seq #13: GCA_900105925.1_Bacteria_Actinomycetota_Jiangella_alkaliphila       Reading seq #14: GCA_900105725.1_Bacteria_Actinomycetota_Gordonia_westfalica       Reading seq #15: GCA_900105385.1_Bacteria_Actinomycetota_Microlunatus_soli       Reading seq #16: GCA_900105175.1_Bacteria_Actinomycetota_Jiangella_sp._DSM_45060       Reading seq #17: GCA_900102755.1_Bacteria_Actinomycetota_Prauserella_marina       Reading seq #18: GCA_900101685.1_Bacteria_Actinomycetota_Actinokineospora_iranica       Reading seq #19: GCA_900100605.1_Bacteria_Actinomycetota_Sinosporangium_album       Reading seq #20: GCA_900100315.1_Bacteria_Actinomycetota_Streptomyces_indicus       Reading seq #21: GCA_900091625.1_Bacteria_Actinomycetota_Micromonospora_peucetia       Reading seq #22: GCA_900091535.1_Bacteria_Actinomycetota_Micromonospora_carbonacea       Reading seq #23: GCA_900091425.1_Bacteria_Actinomycetota_Micromonospora_krabiensis       Reading seq #24: GCA_900090325.1_Bacteria_Actinomycetota_Micromonospora_pallida       Reading seq #25: GCA_900090225.1_Bacteria_Actinomycetota_Micromonospora_eburnea       Reading seq #26: GCA_900070365.1_Bacteria_Actinomycetota_Alloactinosynnema_sp._L_07       Reading seq #27: GCA_030815485.1_Bacteria_Actinomycetota_Streptomyces_rishiriensis       Reading seq #28: GCA_030811575.1_Bacteria_Actinomycetota_Catenuloplanes_nepalensis       Reading seq #29: GCA_030811555.1_Bacteria_Actinomycetota_Kineosporia_succinea       Reading seq #30: GCA_030811375.1_Bacteria_Actinomycetota_Spirilliplanes_yamanashiensis       Reading seq #31: GCA_026167665.1_Bacteria_Actinomycetota_Streptomyces_drozdowiczii       Reading seq #32: GCA_024662375.1_Bacteria_Actinomycetota_Pimelobacter_simplex       Reading seq #33: GCA_024172095.1_Bacteria_Actinomycetota_Kitasatospora_paracochleata       Reading seq #34: GCA_024171925.1_Bacteria_Actinomycetota_Actinokineospora_diospyrosa       Reading seq #35: GCA_024171785.1_Bacteria_Actinomycetota_Goodfellowiella_coeruleoviolacea       Reading seq #36: GCA_024134545.1_Bacteria_Actinomycetota_Nocardiopsis_exhalans       Reading seq #37: GCA_021183625.1_Bacteria_Actinomycetota_Nocardia_asteroides       Reading seq #38: GCA_021165735.1_Bacteria_Actinomycetota_Yinghuangia_sp._ASG_101       Reading seq #39: GCA_021129235.1_Bacteria_Actinomycetota_Kineosporia_mesophila       Reading seq #40: GCA_019175365.1_Bacteria_Actinomycetota_Actinomadura_graeca       Reading seq #41: GCA_015751905.1_Bacteria_Actinomycetota_Longispora_fulva       Reading seq #42: GCA_015751755.1_Bacteria_Actinomycetota_Actinomadura_viridis       Reading seq #43: GCA_014295435.1_Bacteria_Actinomycetota_Mycolicibacterium_fluoranthenivorans       Reading seq #44: GCA_014263335.1_Bacteria_Actinomycetota_Mycobacterium_kubicae       Reading seq #45: GCA_014216315.1_Bacteria_Actinomycetota_Streptomyces_finlayi       Reading seq #46: GCA_014207705.1_Bacteria_Actinomycetota_Sphaerisporangium_rubeum       Reading seq #47: GCA_014205275.1_Bacteria_Actinomycetota_Sphaerisporangium_siamense       Reading seq #48: GCA_014204975.1_Bacteria_Actinomycetota_Jiangella_mangrovi       Reading seq #49: GCA_014204915.1_Bacteria_Actinomycetota_Crossiella_cryophila       Reading seq #50: GCA_014203835.1_Bacteria_Actinomycetota_Micromonospora_polyrhachis       Reading seq #51: GCA_014203805.1_Bacteria_Actinomycetota_Lipingzhangella_halophila       Reading seq #52: GCA_014203605.1_Bacteria_Actinomycetota_Planomonospora_venezuelensis       Reading seq #53: GCA_014203235.1_Bacteria_Actinomycetota_Nonomuraea_endophytica       Reading seq #54: GCA_014202425.1_Bacteria_Actinomycetota_Phytomonospora_endophytica       Reading seq #55: GCA_014200805.1_Bacteria_Actinomycetota_Nocardiopsis_composta       Reading seq #56: GCA_014084105.1_Bacteria_Actinomycetota_Streptacidiphilus_sp._P02_A3a       Reading seq #57: GCA_013744875.1_Bacteria_Actinomycetota_Nocardia_huaxiensis       Reading seq #58: GCA_013409365.1_Bacteria_Actinomycetota_Actinomadura_luteofluorescens       Reading seq #59: GCA_011694815.1_Bacteria_Actinomycetota_Streptomyces_liangshanensis       Reading seq #60: GCA_009296025.1_Bacteria_Actinomycetota_Streptomyces_tsukubensis       Reading seq #61: GCA_008704205.1_Bacteria_Actinomycetota_Nocardia_colli       Reading seq #62: GCA_008630535.1_Bacteria_Actinomycetota_Saccharopolyspora_hirsuta       Reading seq #63: GCA_008386585.1_Bacteria_Actinomycetota_Solihabitans_fulvus       Reading seq #64: GCA_008329605.1_Bacteria_Actinomycetota_Mycolicibacterium_sp._P9_64       Reading seq #65: GCA_008085905.1_Bacteria_Actinomycetota_Actinomadura_syzygii       Reading seq #66: GCA_007993965.1_Bacteria_Actinomycetota_Prauserella_muralis       Reading seq #67: GCA_007856155.1_Bacteria_Actinomycetota_Streptomyces_qinzhouensis       Reading seq #68: GCA_007845675.1_Bacteria_Actinomycetota_Lentzea_tibetensis       Reading seq #69: GCA_007828955.1_Bacteria_Actinomycetota_Kitasatospora_atroaurantiaca       Reading seq #70: GCA_007828865.1_Bacteria_Actinomycetota_Kribbella_amoyensis       Reading seq #71: GCA_007713755.1_Bacteria_Actinomycetota_Amycolatopsis_bartoniae       Reading seq #72: GCA_006912135.1_Bacteria_Actinomycetota_Cryptosporangium_phraense       Reading seq #73: GCA_006717045.1_Bacteria_Actinomycetota_Pseudonocardia_cypriaca       Reading seq #74: GCA_006716765.1_Bacteria_Actinomycetota_Actinomadura_hallensis       Reading seq #75: GCA_006716565.1_Bacteria_Actinomycetota_Nocardia_bhagyanarayanae       Reading seq #76: GCA_006716425.1_Bacteria_Actinomycetota_Actinoallomurus_bryophytorum       Reading seq #77: GCA_006715045.1_Bacteria_Actinomycetota_Amycolatopsis_cihanbeyliensis       Reading seq #78: GCA_006547175.1_Bacteria_Actinomycetota_Streptomyces_ipomoeae       Reading seq #79: GCA_006334985.2_Bacteria_Actinomycetota_Nonomuraea_phyllanthi       Reading seq #80: GCA_004363095.1_Bacteria_Actinomycetota_Actinomycetospora_succinea       Reading seq #81: GCA_004362825.1_Bacteria_Actinomycetota_Labedaea_rhizosphaerae       Reading seq #82: GCA_004349235.1_Bacteria_Actinomycetota_Actinomadura_darangshiensis       Reading seq #83: GCA_004349065.1_Bacteria_Actinomycetota_Jiangella_asiatica       Reading seq #84: GCA_004349055.1_Bacteria_Actinomycetota_Kribbella_antibiotica       Reading seq #85: GCA_004348985.1_Bacteria_Actinomycetota_Saccharopolyspora_elongata       Reading seq #86: GCA_004348725.1_Bacteria_Actinomycetota_Kribbella_turkmenica       Reading seq #87: GCA_004340875.1_Bacteria_Actinomycetota_Tamaricihabitans_halophyticus       Reading seq #88: GCA_004331345.1_Bacteria_Actinomycetota_Kribbella_soli       Reading seq #89: GCA_004310055.1_Bacteria_Actinomycetota_Mycolicibacterium_smegmatis       Reading seq #90: GCA_004217545.1_Bacteria_Actinomycetota_Krasilnikovia_cinnamomea       Reading seq #91: GCA_004217185.1_Bacteria_Actinomycetota_Pseudonocardia_sediminis       Reading seq #92: GCA_004214935.1_Bacteria_Actinomycetota_Amycolatopsis_suaedae       Reading seq #93: GCA_003970715.1_Bacteria_Actinomycetota_Streptomyces_luteoverticillatus       Reading seq #94: GCA_003967355.1_Bacteria_Actinomycetota_Embleya_hyalina       Reading seq #95: GCA_003675325.1_Bacteria_Actinomycetota_Streptomyces_dangxiongensis       Reading seq #96: GCA_003674045.1_Bacteria_Actinomycetota_Streptomyces_griseocarneus       Reading seq #97: GCA_003633755.1_Bacteria_Actinomycetota_Solirubrobacter_pauli       Reading seq #98: GCA_003633685.1_Bacteria_Actinomycetota_Micromonospora_pisi       Reading seq #99: GCA_003627815.1_Bacteria_Actinomycetota_Streptomyces_hundungensis       Reading seq #100: GCA_003626655.1_Bacteria_Actinomycetota_Micromonospora_costi       Reading seq #101: GCA_003626635.1_Bacteria_Actinomycetota_Micromonospora_musae       Reading seq #102: GCA_003626585.1_Bacteria_Actinomycetota_Streptomyces_radicis       Reading seq #103: GCA_003610785.1_Bacteria_Actinomycetota_Micromonospora_globbae       Reading seq #104: GCA_003600245.1_Bacteria_Actinomycetota_Amycolatopsis_panacis       Reading seq #105: GCA_003600225.1_Bacteria_Actinomycetota_Pseudonocardiaceae_bacterium_YIM_PH_21723       Reading seq #106: GCA_003598715.1_Bacteria_Actinomycetota_Nocardia_panacis       Reading seq #107: GCA_003515065.1_Bacteria_Actinomycetota_Nocardioides_immobilis       Reading seq #108: GCA_003432485.1_Bacteria_Actinomycetota_Actinomadura_spongiicola       Reading seq #109: GCA_003387475.1_Bacteria_Actinomycetota_Kutzneria_buriramensis       Reading seq #110: GCA_003386555.1_Bacteria_Actinomycetota_Thermomonospora_umbrina       Reading seq #111: GCA_003355155.1_Bacteria_Actinomycetota_Streptomyces_armeniacus       Reading seq #112: GCA_003347205.1_Bacteria_Actinomycetota_Mycolicibacterium_moriokaense       Reading seq #113: GCA_003323735.1_Bacteria_Actinomycetota_Streptomyces_reniochalinae       Reading seq #114: GCA_003312875.1_Bacteria_Actinomycetota_Amycolatopsis_albispora       Reading seq #115: GCA_003289645.1_Bacteria_Actinomycetota_Actinomadura_craniellae       Reading seq #116: GCA_003258605.2_Bacteria_Actinomycetota_Peterkaempfera_bronchialis       Reading seq #117: GCA_003236295.1_Bacteria_Actinomycetota_Jiangella_anatolica       Reading seq #118: GCA_003217475.1_Bacteria_Actinomycetota_Williamsia_limnetica       Reading seq #119: GCA_003205575.1_Bacteria_Actinomycetota_Streptomyces_tateyamensis       Reading seq #120: GCA_003202235.1_Bacteria_Actinomycetota_Prauserella_flavalba       Reading seq #121: GCA_003058225.1_Bacteria_Actinomycetota_Promicromonospora_sp._AC04       Reading seq #122: GCA_003030385.1_Bacteria_Actinomycetota_Plantactinospora_sp._BB1       Reading seq #123: GCA_003014735.1_Bacteria_Actinomycetota_Saccharothrix_carnea       Reading seq #124: GCA_003014485.1_Bacteria_Actinomycetota_Murinocardiopsis_flavida       Reading seq #125: GCA_003002815.1_Bacteria_Actinomycetota_Umezawaea_tangerina       Reading seq #126: GCA_003002095.1_Bacteria_Actinomycetota_Allonocardiopsis_opalescens       Reading seq #127: GCA_003001935.1_Bacteria_Actinomycetota_Nonomuraea_fuscirosea       Reading seq #128: GCA_002934265.1_Bacteria_Actinomycetota_Actinokineospora_auranticolor       Reading seq #129: GCA_002335465.1_Bacteria_Actinomycetota_Streptomyces_olivochromogenes       Reading seq #130: GCA_002236815.1_Bacteria_Actinomycetota_Nocardia_cerradoensis       Reading seq #131: GCA_002086155.1_Bacteria_Actinomycetota_Mycobacterium_angelicum       Reading seq #132: GCA_001941645.1_Bacteria_Actinomycetota_Actinoalloteichus_sp._GBA129_24       Reading seq #133: GCA_001940455.1_Bacteria_Actinomycetota_Actinokineospora_bangkokensis       Reading seq #134: GCA_001886715.1_Bacteria_Actinomycetota_Nocardia_mangyaensis       Reading seq #135: GCA_001885535.1_Bacteria_Actinomycetota_Nocardia_seriolae       Reading seq #136: GCA_001866645.1_Bacteria_Actinomycetota_Streptomyces_colonosanans       Reading seq #137: GCA_001854805.1_Bacteria_Actinomycetota_Pseudofrankia_sp._BMG5.36       Reading seq #138: GCA_001854695.1_Bacteria_Actinomycetota_Parafrankia_soli       Reading seq #139: GCA_001746425.1_Bacteria_Actinomycetota_Streptomyces_subrutilus       Reading seq #140: GCA_001701025.1_Bacteria_Actinomycetota_Lentzea_guizhouensis       Reading seq #141: GCA_001675225.1_Bacteria_Actinomycetota_Mycobacterium_gordonae       Reading seq #142: GCA_001611795.1_Bacteria_Actinomycetota_Streptomyces_qaidamensis       Reading seq #143: GCA_001570485.1_Bacteria_Actinomycetota_Mycolicibacterium_novocastrense       Reading seq #144: GCA_001542325.1_Bacteria_Actinomycetota_Micromonospora_rifamycinica       Reading seq #145: GCA_001509495.1_Bacteria_Actinomycetota_Actinoplanes_awajinensis_subsp._mycoplanecinus       Reading seq #146: GCA_001482415.1_Bacteria_Actinomycetota_Streptomyces_silvensis       Reading seq #147: GCA_001373395.1_Bacteria_Actinomycetota_Mycobacterium_lentiflavum       Reading seq #148: GCA_001302585.1_Bacteria_Actinomycetota_Kibdelosporangium_phytohabitans       Reading seq #149: GCA_001187435.1_Bacteria_Actinomycetota_Streptomyces_caatingaensis       Reading seq #150: GCA_001077745.1_Bacteria_Actinomycetota_Mycolicibacterium_conceptionense       Reading seq #151: GCA_000980885.2_Bacteria_Actinomycetota_Streptomyces_malaysiense       Reading seq #152: GCA_000966975.1_Bacteria_Actinomycetota_Streptomyces_katrae       Reading seq #153: GCA_000935125.1_Bacteria_Actinomycetota_Streptomyces_natalensis_ATCC_27448       Reading seq #154: GCA_000931445.1_Bacteria_Actinomycetota_Streptomyces_cyaneogriseus_subsp._noncyanogenus       Reading seq #155: GCA_000785985.1_Bacteria_Actinomycetota_Actinoplanes_utahensis       Reading seq #156: GCA_000739085.1_Bacteria_Actinomycetota_Amycolatopsis_methanolica_239       Reading seq #157: GCA_000494755.1_Bacteria_Actinomycetota_Actinoplanes_friuliensis_DSM_7358       Reading seq #158: GCA_000444875.1_Bacteria_Actinomycetota_Streptomyces_collinus_Tu_365       Reading seq #159: GCA_000266905.1_Bacteria_Actinomycetota_Mycolicibacterium_chubuense_NBB4       Reading seq #160: GCA_000196675.2_Bacteria_Actinomycetota_Pseudonocardia_dioxanivorans_CB1190       Reading seq #161: GCA_000166135.1_Bacteria_Actinomycetota_Pseudofrankia_inefficax       Reading seq #162: GCA_000024545.1_Bacteria_Actinomycetota_Stackebrandtia_nassauensis_DSM_44728       Reading seq #163: GCA_000024345.1_Bacteria_Actinomycetota_Kribbella_flavida_DSM_17836       Reading seq #164: GCA_000024025.1_Bacteria_Actinomycetota_Catenulispora_acidiphila_DSM_44928       Reading seq #165: GCA_000014565.1_Bacteria_Actinomycetota_Rhodococcus_jostii_RHA1       
Sequences read..
Counting site patterns..  0:00
Compressing,   1987 patterns at   2047 /   2047 sites (100.0%),  0:00
Collecting fpatt[] & pose[],   1987 patterns at   2047 /   2047 sites (100.0%),  0:00
1 ambiguous codons are seen in the data:
 ---
Counting codons..

   108240 bytes for distance
  1939312 bytes for conP
140724431874344 bytes for fhK
  5000000 bytes for space

TREE #  1

158053928 bytes for conP, adjusted

8 node(s) used for scaling (Yang 2000 J Mol Evol 51:423-432):
 172 177 184 213 223 242 246 281

ntime & nrate & np:   327     2   329

np =   329
lnL0 = -255729.950824

Iterating by ming2
Initial: fx= 255729.950824
x=  0.04610  0.01132  0.07633  0.04361  0.10345  0.06482  0.06897  0.07392  0.06788  0.10717  0.09813  0.06894  0.04247  0.05274  0.04112  0.03095  0.08022  0.04008  0.10592  0.02054  0.09523  0.02885  0.04153  0.02086  0.06400  0.04974  0.09386  0.02599  0.04650  0.09343  0.02445  0.07685  0.03183  0.09936  0.08421  0.04317  0.08803  0.08039  0.10925  0.02480  0.07080  0.09424  0.08112  0.02101  0.02075  0.04763  0.06857  0.09096  0.05399  0.09406  0.04304  0.10402  0.02560  0.06124  0.03510  0.05326  0.02077  0.01896  0.07394  0.08048  0.10324  0.07348  0.02721  0.03645  0.02580  0.04931  0.03328  0.07447  0.08243  0.09436  0.09326  0.05099  0.05684  0.01929  0.06474  0.08156  0.09715  0.05717  0.07471  0.07561  0.02122  0.10419  0.04363  0.04840  0.03253  0.07759  0.08792  0.08375  0.10115  0.10146  0.04313  0.09585  0.03951  0.10665  0.02478  0.01360  0.07775  0.10550  0.01928  0.08604  0.01820  0.07742  0.07200  0.08205  0.02379  0.07627  0.01464  0.03310  0.07004  0.04542  0.04923  0.04221  0.06524  0.10151  0.08077  0.05766  0.01871  0.02278  0.06587  0.08488  0.01154  0.05288  0.01945  0.08505  0.09979  0.10622  0.09670  0.08359  0.05461  0.03570  0.04264  0.08734  0.01912  0.09871  0.07617  0.08350  0.03663  0.03253  0.05117  0.06907  0.07998  0.02486  0.01149  0.03402  0.08659  0.04050  0.03223  0.09673  0.07899  0.04017  0.01449  0.06515  0.02550  0.10231  0.07558  0.07200  0.07072  0.03390  0.05219  0.10763  0.04050  0.03109  0.10846  0.04877  0.10114  0.02578  0.01616  0.05680  0.02753  0.02889  0.04936  0.09385  0.10974  0.05643  0.01055  0.08021  0.10297  0.09908  0.08048  0.09148  0.10042  0.07154  0.05900  0.06896  0.08380  0.05229  0.03890  0.09156  0.08116  0.09982  0.03015  0.03288  0.03672  0.10631  0.02655  0.10167  0.07241  0.02463  0.08204  0.03934  0.09584  0.07960  0.03895  0.02277  0.08424  0.04948  0.02517  0.09591  0.04928  0.07860  0.01266  0.02872  0.06224  0.05712  0.10432  0.07668  0.09438  0.07877  0.09148  0.08952  0.10214  0.06257  0.09917  0.09243  0.06177  0.09945  0.01140  0.03831  0.03326  0.05972  0.04359  0.10445  0.10810  0.07234  0.10434  0.08207  0.07062  0.06181  0.06378  0.08219  0.07761  0.10385  0.02061  0.05618  0.03586  0.03556  0.03507  0.10461  0.03237  0.03116  0.07008  0.02260  0.04687  0.02917  0.05752  0.10531  0.05132  0.07200  0.08219  0.01189  0.07619  0.09392  0.05024  0.06138  0.09803  0.06822  0.08464  0.10896  0.07819  0.09966  0.06450  0.02604  0.05724  0.02307  0.10083  0.08255  0.08491  0.04397  0.01554  0.10497  0.04010  0.03230  0.06614  0.05846  0.07077  0.05507  0.03319  0.07649  0.05826  0.10893  0.06278  0.03657  0.08593  0.08854  0.03115  0.05534  0.06656  0.10181  0.07362  0.05157  0.05844  0.01772  0.09514  0.10040  0.07462  0.10792  0.05455  0.07743  0.06517  0.01787  0.08971  0.06595  0.02708  0.07846  0.02578  0.07570  0.07143  0.04418  0.08381  0.09687  0.05263  0.01861  0.08173  0.08743  0.03935  0.10334  0.09512  1.00000  0.50000

  1 h-m-p  0.0000 0.0000 62560.3995 +YYYYCCCC 228770.660101  7 0.0000   345 | 0/329
  2 h-m-p  0.0000 0.0001 34756.9942 CYCCCC 227098.480060  5 0.0000   686 | 0/329
  3 h-m-p  0.0000 0.0001 14793.4602 ++    220804.773565  m 0.0001  1018 | 0/329
  4 h-m-p  0.0000 0.0000 88379.0146 +YCCCC 220595.814731  4 0.0000  1358 | 0/329
  5 h-m-p  0.0000 0.0000 10992.6319 YCCC  220258.351251  3 0.0000  1695 | 0/329
  6 h-m-p  0.0000 0.0001 4026.2579 YCCC  219968.939441  3 0.0001  2032 | 0/329
  7 h-m-p  0.0000 0.0001 2776.2158 +YCCC 219765.911474  3 0.0001  2370 | 0/329
  8 h-m-p  0.0000 0.0002 1612.3186 YC    219698.368220  1 0.0001  2703 | 0/329
  9 h-m-p  0.0001 0.0006 910.0641 CCC   219671.558251  2 0.0001  3039 | 0/329
 10 h-m-p  0.0001 0.0003 524.3007 YCCC  219661.379033  3 0.0001  3376 | 0/329
 11 h-m-p  0.0001 0.0003 388.4299 CC    219658.134358  1 0.0001  3710 | 0/329
 12 h-m-p  0.0001 0.0024 237.6087 C     219655.889848  0 0.0001  4042 | 0/329
 13 h-m-p  0.0002 0.0020 153.6614 CC    219654.479743  1 0.0001  4376 | 0/329
 14 h-m-p  0.0001 0.0009 156.9981 CC    219653.333358  1 0.0001  4710 | 0/329
 15 h-m-p  0.0002 0.0019 122.8513 CC    219651.711538  1 0.0002  5044 | 0/329
 16 h-m-p  0.0002 0.0030 147.3834 CC    219649.349812  1 0.0002  5378 | 0/329
 17 h-m-p  0.0001 0.0009 196.8621 CC    219643.835457  1 0.0002  5712 | 0/329
 18 h-m-p  0.0002 0.0023 258.7389 CCC   219631.455446  2 0.0002  6048 | 0/329
 19 h-m-p  0.0001 0.0003 454.0295 +CYC  219603.040225  2 0.0002  6384 | 0/329
 20 h-m-p  0.0001 0.0005 855.8595 YCC   219552.089282  2 0.0002  6719 | 0/329
 21 h-m-p  0.0001 0.0004 933.9918 +YCC  219435.582200  2 0.0002  7055 | 0/329
 22 h-m-p  0.0000 0.0001 1385.1882 ++    219227.287406  m 0.0001  7387 | 0/329
 23 h-m-p  0.0000 0.0001 3525.2664 ++    218962.845694  m 0.0001  7719 | 0/329
 24 h-m-p  0.0000 0.0000 29924.9312 ++    218882.784660  m 0.0000  8051 | 0/329
 25 h-m-p  0.0000 0.0000 18677.6496 +YCCC 218822.644560  3 0.0000  8389 | 0/329
 26 h-m-p  0.0000 0.0000 6416.7408 ++    218598.898016  m 0.0000  8721 | 0/329
 27 h-m-p  0.0000 0.0000 21912.0703 YCCCC 218571.681942  4 0.0000  9060 | 0/329
 28 h-m-p  0.0000 0.0001 8890.1088 ++    217934.285028  m 0.0001  9392 | 0/329
 29 h-m-p  0.0000 0.0000 118140.7283 YCYC  217862.797830  3 0.0000  9728 | 0/329
 30 h-m-p  0.0000 0.0001 4371.6488 ++    217381.602327  m 0.0001 10060 | 0/329
 31 h-m-p  0.0000 0.0002 3809.4700 +CCC  216887.806654  2 0.0001 10397 | 0/329
 32 h-m-p  0.0000 0.0002 2178.0527 ++    216500.190950  m 0.0002 10729 | 0/329
 33 h-m-p  0.0000 0.0000 7103.4740 +YCC  216411.716891  2 0.0000 11065 | 0/329
 34 h-m-p  0.0000 0.0002 2407.9380 +YYYYC 216174.998342  4 0.0001 11402 | 0/329
 35 h-m-p  0.0000 0.0001 2543.1184 +CYCCC 216076.696421  4 0.0001 11742 | 0/329
 36 h-m-p  0.0001 0.0003 1663.1105 YCCC  215974.525190  3 0.0001 12079 | 0/329
 37 h-m-p  0.0001 0.0004 1286.0077 YC    215912.009023  1 0.0002 12412 | 0/329
 38 h-m-p  0.0001 0.0004 1471.5407 YC    215840.807750  1 0.0002 12745 | 0/329
 39 h-m-p  0.0001 0.0003 1358.8919 +YYCCC 215782.044592  4 0.0002 13084 | 0/329
 40 h-m-p  0.0001 0.0004 1618.5989 CCC   215746.546372  2 0.0001 13420 | 0/329
 41 h-m-p  0.0001 0.0003 1059.8338 +YCCC 215716.993449  3 0.0002 13758 | 0/329
 42 h-m-p  0.0001 0.0005 802.4837 CCC   215697.623364  2 0.0002 14094 | 0/329
 43 h-m-p  0.0001 0.0006 507.2834 CC    215687.675298  1 0.0002 14428 | 0/329
 44 h-m-p  0.0002 0.0009 505.0577 C     215679.303983  0 0.0002 14760 | 0/329
 45 h-m-p  0.0002 0.0010 253.3732 C     215675.119587  0 0.0002 15092 | 0/329
 46 h-m-p  0.0001 0.0007 203.3047 CCC   215671.563573  2 0.0002 15428 | 0/329
 47 h-m-p  0.0002 0.0020 194.3497 CC    215666.433824  1 0.0003 15762 | 0/329
 48 h-m-p  0.0002 0.0012 223.9408 CCC   215658.968293  2 0.0003 16098 | 0/329
 49 h-m-p  0.0003 0.0023 264.3124 YC    215642.880849  1 0.0004 16431 | 0/329
 50 h-m-p  0.0002 0.0012 368.8469 CCC   215614.429201  2 0.0004 16767 | 0/329
 51 h-m-p  0.0002 0.0011 622.5735 CCC   215569.164058  2 0.0003 17103 | 0/329
 52 h-m-p  0.0001 0.0004 703.3475 +YCCC 215500.705277  3 0.0003 17441 | 0/329
 53 h-m-p  0.0001 0.0003 1210.4298 +YCY  215426.836978  2 0.0002 17777 | 0/329
 54 h-m-p  0.0002 0.0010 936.1562 YCC   215251.300643  2 0.0004 18112 | 0/329
 55 h-m-p  0.0001 0.0005 856.5353 +CYC  215009.982483  2 0.0004 18448 | 0/329
 56 h-m-p  0.0000 0.0002 1566.0464 +CYC  214860.363506  2 0.0002 18784 | 0/329
 57 h-m-p  0.0001 0.0004 1096.6076 ++    214623.573365  m 0.0004 19116 | 0/329
 58 h-m-p  0.0000 0.0001 2433.7779 +YCC  214566.820232  2 0.0001 19452 | 0/329
 59 h-m-p  0.0001 0.0007 1217.9418 YC    214424.031769  1 0.0003 19785 | 0/329
 60 h-m-p  0.0001 0.0007 981.7114 +YCCC 214301.016616  3 0.0004 20123 | 0/329
 61 h-m-p  0.0001 0.0007 783.2076 YCCC  214255.854651  3 0.0003 20460 | 0/329
 62 h-m-p  0.0001 0.0007 477.7149 YCCC  214238.828321  3 0.0002 20797 | 0/329
 63 h-m-p  0.0004 0.0020 303.2335 CC    214229.636753  1 0.0003 21131 | 0/329
 64 h-m-p  0.0002 0.0011 236.8440 CCC   214225.473154  2 0.0002 21467 | 0/329
 65 h-m-p  0.0004 0.0030 155.0696 CC    214223.017386  1 0.0003 21801 | 0/329
 66 h-m-p  0.0005 0.0040  95.5898 CC    214220.661698  1 0.0005 22135 | 0/329
 67 h-m-p  0.0006 0.0041  88.1407 C     214218.028076  0 0.0006 22467 | 0/329
 68 h-m-p  0.0004 0.0031 123.1455 CC    214213.800587  1 0.0005 22801 | 0/329
 69 h-m-p  0.0005 0.0031 135.1062 YCC   214203.739378  2 0.0007 23136 | 0/329
 70 h-m-p  0.0005 0.0034 217.4509 YC    214180.275351  1 0.0008 23469 | 0/329
 71 h-m-p  0.0003 0.0014 387.0530 YC    214133.454612  1 0.0007 23802 | 0/329
 72 h-m-p  0.0003 0.0014 534.0915 YCCC  214078.395254  3 0.0005 24139 | 0/329
 73 h-m-p  0.0003 0.0015 541.5326 CCC   214017.267359  2 0.0005 24475 | 0/329
 74 h-m-p  0.0002 0.0009 547.3717 YCCC  213970.025007  3 0.0004 24812 | 0/329
 75 h-m-p  0.0002 0.0008 522.0604 +YCC  213923.393104  2 0.0004 25148 | 0/329
 76 h-m-p  0.0003 0.0014 564.3127 CCC   213882.873677  2 0.0004 25484 | 0/329
 77 h-m-p  0.0003 0.0013 525.0159 YCCC  213847.721063  3 0.0005 25821 | 0/329
 78 h-m-p  0.0002 0.0010 655.0680 YCCC  213818.997228  3 0.0004 26158 | 0/329
 79 h-m-p  0.0004 0.0018 537.8714 CCC   213797.097405  2 0.0004 26494 | 0/329
 80 h-m-p  0.0003 0.0017 297.5815 CC    213789.457155  1 0.0003 26828 | 0/329
 81 h-m-p  0.0003 0.0016 186.6605 CYC   213786.593954  2 0.0003 27163 | 0/329
 82 h-m-p  0.0005 0.0037  98.1394 YC    213785.361985  1 0.0004 27496 | 0/329
 83 h-m-p  0.0005 0.0028  70.0335 CY    213784.506433  1 0.0004 27830 | 0/329
 84 h-m-p  0.0005 0.0058  59.3027 CC    213783.596256  1 0.0005 28164 | 0/329
 85 h-m-p  0.0005 0.0059  59.5379 CC    213782.209618  1 0.0007 28498 | 0/329
 86 h-m-p  0.0005 0.0087  77.7989 CC    213779.548797  1 0.0007 28832 | 0/329
 87 h-m-p  0.0007 0.0057  87.9562 CCC   213773.411655  2 0.0010 29168 | 0/329
 88 h-m-p  0.0006 0.0034 153.9448 YC    213756.297888  1 0.0010 29501 | 0/329
 89 h-m-p  0.0004 0.0020 268.4837 YCCC  213718.219188  3 0.0009 29838 | 0/329
 90 h-m-p  0.0004 0.0019 348.7008 YCCC  213656.747687  3 0.0008 30175 | 0/329
 91 h-m-p  0.0003 0.0013 445.7197 +YCCC 213556.572602  3 0.0007 30513 | 0/329
 92 h-m-p  0.0002 0.0012 617.3940 +YCCC 213428.360100  3 0.0006 30851 | 0/329
 93 h-m-p  0.0001 0.0006 908.1204 +YCCC 213301.181714  3 0.0004 31189 | 0/329
 94 h-m-p  0.0001 0.0007 619.5271 +YC   213243.918831  1 0.0004 31523 | 0/329
 95 h-m-p  0.0001 0.0007 402.8805 YCCC  213222.334182  3 0.0003 31860 | 0/329
 96 h-m-p  0.0003 0.0016 325.5233 CCC   213209.534595  2 0.0004 32196 | 0/329
 97 h-m-p  0.0003 0.0013 272.7869 CCC   213202.066772  2 0.0004 32532 | 0/329
 98 h-m-p  0.0003 0.0015 216.7188 CCC   213198.076262  2 0.0003 32868 | 0/329
 99 h-m-p  0.0006 0.0048 133.1044 CC    213195.412433  1 0.0005 33202 | 0/329
100 h-m-p  0.0007 0.0063 106.6835 YC    213194.030615  1 0.0004 33535 | 0/329
101 h-m-p  0.0006 0.0074  75.2914 YC    213193.274958  1 0.0004 33868 | 0/329
102 h-m-p  0.0007 0.0071  48.8503 YC    213192.809902  1 0.0005 34201 | 0/329
103 h-m-p  0.0007 0.0224  37.0102 C     213192.368837  0 0.0006 34533 | 0/329
104 h-m-p  0.0007 0.0124  33.6536 CC    213191.673669  1 0.0008 34867 | 0/329
105 h-m-p  0.0008 0.0138  36.7816 YC    213189.626115  1 0.0014 35200 | 0/329
106 h-m-p  0.0007 0.0042  71.9983 CC    213184.586727  1 0.0011 35534 | 0/329
107 h-m-p  0.0006 0.0037 131.5808 YC    213171.926319  1 0.0010 35867 | 0/329
108 h-m-p  0.0006 0.0029 211.9544 CCC   213146.527542  2 0.0009 36203 | 0/329
109 h-m-p  0.0003 0.0017 280.5345 YCCC  213108.467068  3 0.0008 36540 | 0/329
110 h-m-p  0.0003 0.0014 355.7972 YC    213064.282620  1 0.0007 36873 | 0/329
111 h-m-p  0.0002 0.0011 452.0566 +YC   213021.229276  1 0.0006 37207 | 0/329
112 h-m-p  0.0004 0.0019 398.9237 CCC   212996.139408  2 0.0005 37543 | 0/329
113 h-m-p  0.0002 0.0011 285.1797 YC    212985.722557  1 0.0004 37876 | 0/329
114 h-m-p  0.0005 0.0026 205.5714 YCC   212980.721557  2 0.0004 38211 | 0/329
115 h-m-p  0.0004 0.0021 112.2247 CC    212978.849131  1 0.0004 38545 | 0/329
116 h-m-p  0.0007 0.0066  75.4680 YC    212978.012715  1 0.0005 38878 | 0/329
117 h-m-p  0.0007 0.0082  49.7371 YC    212977.664928  1 0.0004 39211 | 0/329
118 h-m-p  0.0008 0.0292  25.9105 YC    212977.497983  1 0.0006 39544 | 0/329
119 h-m-p  0.0008 0.0270  19.4934 C     212977.355070  0 0.0007 39876 | 0/329
120 h-m-p  0.0007 0.0248  20.2678 CC    212977.141985  1 0.0008 40210 | 0/329
121 h-m-p  0.0008 0.0400  22.5314 CC    212976.702729  1 0.0011 40544 | 0/329
122 h-m-p  0.0007 0.0137  34.4260 YC    212975.565684  1 0.0012 40877 | 0/329
123 h-m-p  0.0007 0.0119  55.9810 CC    212973.158595  1 0.0010 41211 | 0/329
124 h-m-p  0.0007 0.0054  80.6537 CC    212967.307780  1 0.0010 41545 | 0/329
125 h-m-p  0.0006 0.0051 144.7109 YC    212952.636079  1 0.0010 41878 | 0/329
126 h-m-p  0.0007 0.0033 211.8374 CCC   212930.645547  2 0.0008 42214 | 0/329
127 h-m-p  0.0004 0.0018 286.0072 YCCC  212907.542590  3 0.0006 42551 | 0/329
128 h-m-p  0.0004 0.0019 283.9926 CCC   212891.878615  2 0.0005 42887 | 0/329
129 h-m-p  0.0006 0.0029 267.8143 CCC   212881.893380  2 0.0005 43223 | 0/329
130 h-m-p  0.0007 0.0036 173.4398 YCC   212877.308415  2 0.0005 43558 | 0/329
131 h-m-p  0.0006 0.0056 134.1282 YC    212875.186801  1 0.0004 43891 | 0/329
132 h-m-p  0.0008 0.0112  72.7748 YC    212874.355206  1 0.0005 44224 | 0/329
133 h-m-p  0.0007 0.0105  49.3168 YC    212874.009084  1 0.0005 44557 | 0/329
134 h-m-p  0.0008 0.0182  28.7623 YC    212873.869115  1 0.0005 44890 | 0/329
135 h-m-p  0.0007 0.0440  20.2512 C     212873.770979  0 0.0006 45222 | 0/329
136 h-m-p  0.0008 0.0487  17.4455 C     212873.688044  0 0.0007 45554 | 0/329
137 h-m-p  0.0008 0.0601  14.4053 C     212873.604762  0 0.0008 45886 | 0/329
138 h-m-p  0.0007 0.0249  16.6818 CC    212873.477971  1 0.0008 46220 | 0/329
139 h-m-p  0.0006 0.0337  20.7590 YC    212873.190086  1 0.0010 46553 | 0/329
140 h-m-p  0.0008 0.0266  26.8021 CC    212872.527243  1 0.0012 46887 | 0/329
141 h-m-p  0.0008 0.0128  40.8567 CC    212870.935083  1 0.0012 47221 | 0/329
142 h-m-p  0.0007 0.0113  70.3366 YC    212867.060643  1 0.0011 47554 | 0/329
143 h-m-p  0.0007 0.0062 108.8112 CC    212859.048071  1 0.0011 47888 | 0/329
144 h-m-p  0.0007 0.0033 153.2097 CC    212847.718197  1 0.0009 48222 | 0/329
145 h-m-p  0.0004 0.0020 201.6328 CCC   212838.486431  2 0.0006 48558 | 0/329
146 h-m-p  0.0004 0.0020 179.6972 CC    212833.554646  1 0.0005 48892 | 0/329
147 h-m-p  0.0008 0.0051  99.7948 YC    212831.863609  1 0.0005 49225 | 0/329
148 h-m-p  0.0009 0.0100  51.1948 YC    212831.348173  1 0.0005 49558 | 0/329
149 h-m-p  0.0009 0.0168  30.0983 YC    212831.188973  1 0.0005 49891 | 0/329
150 h-m-p  0.0009 0.0198  16.6555 YC    212831.116534  1 0.0006 50224 | 0/329
151 h-m-p  0.0010 0.0776  10.9565 YC    212831.073011  1 0.0007 50557 | 0/329
152 h-m-p  0.0009 0.0484   8.7974 C     212831.027229  0 0.0009 50889 | 0/329
153 h-m-p  0.0008 0.0470   9.9281 CC    212830.930844  1 0.0012 51223 | 0/329
154 h-m-p  0.0008 0.0505  14.0849 YC    212830.679723  1 0.0014 51556 | 0/329
155 h-m-p  0.0008 0.0335  23.8444 CC    212830.053050  1 0.0013 51890 | 0/329
156 h-m-p  0.0007 0.0149  41.2561 CC    212828.640321  1 0.0011 52224 | 0/329
157 h-m-p  0.0007 0.0070  64.1968 CC    212825.282539  1 0.0011 52558 | 0/329
158 h-m-p  0.0006 0.0028  93.8986 YC    212818.439842  1 0.0011 52891 | 0/329
159 h-m-p  0.0003 0.0013 125.1385 +YCC  212811.639292  2 0.0008 53227 | 0/329
160 h-m-p  0.0003 0.0014 125.5329 YC    212807.479787  1 0.0006 53560 | 0/329
161 h-m-p  0.0002 0.0012  94.5778 YC    212805.779713  1 0.0005 53893 | 0/329
162 h-m-p  0.0008 0.0119  57.4679 YC    212805.111216  1 0.0006 54226 | 0/329
163 h-m-p  0.0003 0.0015  39.7134 YC    212804.851060  1 0.0005 54559 | 0/329
164 h-m-p  0.0008 0.0356  23.8452 YC    212804.738413  1 0.0005 54892 | 0/329
165 h-m-p  0.0006 0.0041  19.2300 C     212804.651046  0 0.0006 55224 | 0/329
166 h-m-p  0.0009 0.0566  12.5269 C     212804.558039  0 0.0010 55556 | 0/329
167 h-m-p  0.0011 0.0421  11.4803 CC    212804.403765  1 0.0013 55890 | 0/329
168 h-m-p  0.0009 0.0463  16.9773 CC    212804.030503  1 0.0014 56224 | 0/329
169 h-m-p  0.0011 0.0287  22.2485 CC    212803.315333  1 0.0013 56558 | 0/329
170 h-m-p  0.0009 0.0238  30.3791 CC    212801.800735  1 0.0014 56892 | 0/329
171 h-m-p  0.0008 0.0084  53.3553 CC    212800.141301  1 0.0009 57226 | 0/329
172 h-m-p  0.0008 0.0089  58.3641 YC    212799.245395  1 0.0006 57559 | 0/329
173 h-m-p  0.0009 0.0129  40.1652 YC    212798.910101  1 0.0005 57892 | 0/329
174 h-m-p  0.0010 0.0354  22.7697 YC    212798.802592  1 0.0005 58225 | 0/329
175 h-m-p  0.0010 0.0324  12.0909 YC    212798.766373  1 0.0006 58558 | 0/329
176 h-m-p  0.0008 0.0895   8.5844 C     212798.734541  0 0.0008 58890 | 0/329
177 h-m-p  0.0010 0.0933   7.0048 C     212798.693191  0 0.0012 59222 | 0/329
178 h-m-p  0.0010 0.1111   8.5434 CC    212798.607351  1 0.0014 59556 | 0/329
179 h-m-p  0.0010 0.0445  11.5791 CC    212798.409023  1 0.0015 59890 | 0/329
180 h-m-p  0.0009 0.0518  18.0802 YC    212797.755582  1 0.0018 60223 | 0/329
181 h-m-p  0.0011 0.0277  28.3924 CC    212795.966460  1 0.0018 60557 | 0/329
182 h-m-p  0.0009 0.0139  58.4628 YC    212791.489503  1 0.0014 60890 | 0/329
183 h-m-p  0.0009 0.0076  91.2162 CC    212786.046577  1 0.0010 61224 | 0/329
184 h-m-p  0.0010 0.0086  92.3260 YC    212783.003532  1 0.0007 61557 | 0/329
185 h-m-p  0.0011 0.0129  61.6547 YC    212782.113803  1 0.0006 61890 | 0/329
186 h-m-p  0.0011 0.0306  32.8802 YC    212781.858504  1 0.0006 62223 | 0/329
187 h-m-p  0.0012 0.0479  15.7922 YC    212781.798264  1 0.0006 62556 | 0/329
188 h-m-p  0.0012 0.0994   7.4362 YC    212781.779792  1 0.0007 62889 | 0/329
189 h-m-p  0.0012 0.1449   4.0657 C     212781.762340  0 0.0012 63221 | 0/329
190 h-m-p  0.0012 0.1283   4.2101 CC    212781.717977  1 0.0019 63555 | 0/329
191 h-m-p  0.0011 0.1397   7.2502 YC    212781.540425  1 0.0023 63888 | 0/329
192 h-m-p  0.0012 0.0385  13.7266 YC    212780.897845  1 0.0022 64221 | 0/329
193 h-m-p  0.0011 0.0285  28.3622 YC    212778.451831  1 0.0021 64554 | 0/329
194 h-m-p  0.0010 0.0153  59.1053 CC    212772.905757  1 0.0015 64888 | 0/329
195 h-m-p  0.0008 0.0059 106.2888 CY    212767.610030  1 0.0008 65222 | 0/329
196 h-m-p  0.0010 0.0098  88.3842 YC    212765.162644  1 0.0007 65555 | 0/329
197 h-m-p  0.0012 0.0164  51.2241 YC    212764.471134  1 0.0006 65888 | 0/329
198 h-m-p  0.0012 0.0197  27.8573 YC    212764.304616  1 0.0006 66221 | 0/329
199 h-m-p  0.0012 0.0488  13.3499 YC    212764.256843  1 0.0006 66554 | 0/329
200 h-m-p  0.0013 0.1377   6.3980 YC    212764.240028  1 0.0008 66887 | 0/329
201 h-m-p  0.0010 0.1518   4.7360 C     212764.223570  0 0.0010 67219 | 0/329
202 h-m-p  0.0013 0.2292   3.7309 YC    212764.172926  1 0.0024 67552 | 0/329
203 h-m-p  0.0013 0.0664   6.8424 YC    212763.997242  1 0.0022 67885 | 0/329
204 h-m-p  0.0011 0.0550  13.7095 YC    212763.261231  1 0.0023 68218 | 0/329
205 h-m-p  0.0011 0.0157  28.0012 YC    212760.548326  1 0.0021 68551 | 0/329
206 h-m-p  0.0009 0.0120  62.4180 YC    212753.547686  1 0.0016 68884 | 0/329
207 h-m-p  0.0010 0.0051 100.1113 YC    212749.747389  1 0.0007 69217 | 0/329
208 h-m-p  0.0010 0.0102  72.9237 YC    212748.505537  1 0.0006 69550 | 0/329
209 h-m-p  0.0013 0.0199  31.7031 YC    212748.264464  1 0.0006 69883 | 0/329
210 h-m-p  0.0012 0.0509  14.7403 YC    212748.209222  1 0.0006 70216 | 0/329
211 h-m-p  0.0012 0.1080   7.3926 YC    212748.193074  1 0.0006 70549 | 0/329
212 h-m-p  0.0012 0.1069   3.9115 C     212748.179933  0 0.0011 70881 | 0/329
213 h-m-p  0.0014 0.2018   3.1750 CC    212748.149066  1 0.0021 71215 | 0/329
214 h-m-p  0.0013 0.1246   5.2833 YC    212748.037539  1 0.0023 71548 | 0/329
215 h-m-p  0.0012 0.0334  10.3024 YC    212747.491599  1 0.0027 71881 | 0/329
216 h-m-p  0.0012 0.0288  22.8081 YC    212745.449318  1 0.0024 72214 | 0/329
217 h-m-p  0.0010 0.0140  52.8585 CC    212741.499410  1 0.0014 72548 | 0/329
218 h-m-p  0.0009 0.0072  83.2144 C     212738.003230  0 0.0009 72880 | 0/329
219 h-m-p  0.0011 0.0106  65.0254 YC    212736.786939  1 0.0007 73213 | 0/329
220 h-m-p  0.0013 0.0298  32.4680 YC    212736.511615  1 0.0006 73546 | 0/329
221 h-m-p  0.0013 0.0408  15.8068 YC    212736.448729  1 0.0006 73879 | 0/329
222 h-m-p  0.0014 0.1032   6.8431 YC    212736.434507  1 0.0007 74212 | 0/329
223 h-m-p  0.0013 0.1727   3.4276 Y     212736.426421  0 0.0010 74544 | 0/329
224 h-m-p  0.0012 0.2307   2.7776 C     212736.411419  0 0.0018 74876 | 0/329
225 h-m-p  0.0016 0.2674   3.0509 YC    212736.341879  1 0.0036 75209 | 0/329
226 h-m-p  0.0013 0.0856   8.5131 YC    212736.080770  1 0.0025 75542 | 0/329
227 h-m-p  0.0015 0.0463  14.5583 YC    212735.046831  1 0.0028 75875 | 0/329
228 h-m-p  0.0011 0.0102  37.4960 CC    212732.857082  1 0.0015 76209 | 0/329
229 h-m-p  0.0011 0.0170  53.2621 CC    212730.707364  1 0.0010 76543 | 0/329
230 h-m-p  0.0011 0.0189  49.3537 YC    212729.733635  1 0.0008 76876 | 0/329
231 h-m-p  0.0011 0.0244  34.6780 YC    212729.398441  1 0.0007 77209 | 0/329
232 h-m-p  0.0014 0.0584  16.6355 YC    212729.325079  1 0.0007 77542 | 0/329
233 h-m-p  0.0014 0.0800   7.5774 YC    212729.309450  1 0.0006 77875 | 0/329
234 h-m-p  0.0013 0.2132   3.7014 Y     212729.302538  0 0.0009 78207 | 0/329
235 h-m-p  0.0015 0.4965   2.1778 C     212729.294592  0 0.0016 78539 | 0/329
236 h-m-p  0.0016 0.1671   2.2109 YC    212729.269150  1 0.0027 78872 | 0/329
237 h-m-p  0.0013 0.1564   4.4222 YC    212729.130003  1 0.0033 79205 | 0/329
238 h-m-p  0.0015 0.0508   9.6580 YC    212728.358300  1 0.0036 79538 | 0/329
239 h-m-p  0.0012 0.0161  28.4494 CC    212726.550341  1 0.0018 79872 | 0/329
240 h-m-p  0.0010 0.0065  53.2827 CC    212725.143030  1 0.0008 80206 | 0/329
241 h-m-p  0.0012 0.0182  36.3624 YC    212724.752613  1 0.0006 80539 | 0/329
242 h-m-p  0.0014 0.0291  16.3187 YC    212724.677209  1 0.0006 80872 | 0/329
243 h-m-p  0.0018 0.1439   6.0162 C     212724.665509  0 0.0007 81204 | 0/329
244 h-m-p  0.0015 0.1739   2.7604 Y     212724.660950  0 0.0009 81536 | 0/329
245 h-m-p  0.0013 0.5634   1.9422 C     212724.653621  0 0.0018 81868 | 0/329
246 h-m-p  0.0015 0.2873   2.2370 YC    212724.626476  1 0.0029 82201 | 0/329
247 h-m-p  0.0016 0.1761   4.1048 YC    212724.484090  1 0.0036 82534 | 0/329
248 h-m-p  0.0014 0.0665  10.2734 +YC   212723.714303  1 0.0036 82868 | 0/329
249 h-m-p  0.0010 0.0283  38.2424 CC    212722.123381  1 0.0016 83202 | 0/329
250 h-m-p  0.0013 0.0121  47.2060 YC    212721.165637  1 0.0009 83535 | 0/329
251 h-m-p  0.0019 0.0270  23.5507 CC    212721.010896  1 0.0006 83869 | 0/329
252 h-m-p  0.0013 0.0384  11.6821 YC    212720.974525  1 0.0006 84202 | 0/329
253 h-m-p  0.0014 0.1555   5.2290 YC    212720.965405  1 0.0007 84535 | 0/329
254 h-m-p  0.0016 0.2773   2.4666 Y     212720.961673  0 0.0010 84867 | 0/329
255 h-m-p  0.0016 0.5384   1.4756 C     212720.954818  0 0.0023 85199 | 0/329
256 h-m-p  0.0021 0.6345   1.5668 YC    212720.917680  1 0.0046 85532 | 0/329
257 h-m-p  0.0016 0.1619   4.4637 +YC   212720.650101  1 0.0046 85866 | 0/329
258 h-m-p  0.0014 0.0479  14.9794 YC    212719.451402  1 0.0032 86199 | 0/329
259 h-m-p  0.0011 0.0083  44.5160 CC    212718.133451  1 0.0011 86533 | 0/329
260 h-m-p  0.0017 0.0254  29.7944 YC    212717.821023  1 0.0008 86866 | 0/329
261 h-m-p  0.0018 0.0585  12.1840 YC    212717.771021  1 0.0008 87199 | 0/329
262 h-m-p  0.0020 0.0727   4.6292 C     212717.763201  0 0.0008 87531 | 0/329
263 h-m-p  0.0016 0.2596   2.1045 Y     212717.759437  0 0.0012 87863 | 0/329
264 h-m-p  0.0020 0.6148   1.2637 C     212717.750900  0 0.0030 88195 | 0/329
265 h-m-p  0.0020 0.3521   1.8531 YC    212717.702587  1 0.0047 88528 | 0/329
266 h-m-p  0.0020 0.1349   4.3495 +YC   212717.354782  1 0.0053 88862 | 0/329
267 h-m-p  0.0015 0.0497  14.8789 YC    212716.025976  1 0.0030 89195 | 0/329
268 h-m-p  0.0013 0.0218  35.0448 CC    212715.082733  1 0.0011 89529 | 0/329
269 h-m-p  0.0015 0.0322  24.3145 YC    212714.877566  1 0.0007 89862 | 0/329
270 h-m-p  0.0020 0.0625   9.0764 C     212714.852065  0 0.0007 90194 | 0/329
271 h-m-p  0.0016 0.1824   3.9438 Y     212714.846488  0 0.0008 90526 | 0/329
272 h-m-p  0.0023 0.9009   1.3397 Y     212714.844262  0 0.0014 90858 | 0/329
273 h-m-p  0.0023 0.9688   0.8270 Y     212714.836340  0 0.0044 91190 | 0/329
274 h-m-p  0.0022 0.6787   1.6751 +YC   212714.775684  1 0.0061 91853 | 0/329
275 h-m-p  0.0020 0.1904   5.2250 YC    212714.436539  1 0.0044 92186 | 0/329
276 h-m-p  0.0014 0.0375  16.4989 CC    212713.655295  1 0.0019 92520 | 0/329
277 h-m-p  0.0012 0.0280  27.1539 CC    212713.144524  1 0.0010 92854 | 0/329
278 h-m-p  0.0018 0.0307  15.7294 YC    212713.053062  1 0.0008 93187 | 0/329
279 h-m-p  0.0019 0.1743   6.6014 YC    212713.037086  1 0.0008 93520 | 0/329
280 h-m-p  0.0021 0.3098   2.5138 Y     212713.033987  0 0.0009 93852 | 0/329
281 h-m-p  0.0024 0.9121   0.9616 C     212713.031326  0 0.0021 94184 | 0/329
282 h-m-p  0.0029 0.7097   0.7204 +YC   212713.009360  1 0.0080 94847 | 0/329
283 h-m-p  0.0020 0.3089   2.8854 +YC   212712.808798  1 0.0064 95510 | 0/329
284 h-m-p  0.0015 0.0352  12.2855 YC    212711.901458  1 0.0035 95843 | 0/329
285 h-m-p  0.0014 0.0147  30.8338 C     212710.981206  0 0.0014 96175 | 0/329
286 h-m-p  0.0018 0.0268  23.4955 YC    212710.758171  1 0.0009 96508 | 0/329
287 h-m-p  0.0021 0.0272   9.5780 C     212710.731650  0 0.0006 96840 | 0/329
288 h-m-p  0.0021 0.1736   2.9288 C     212710.727932  0 0.0008 97172 | 0/329
289 h-m-p  0.0026 0.9714   0.8928 C     212710.724109  0 0.0027 97504 | 0/329
290 h-m-p  0.0024 0.8402   1.0160 +YC   212710.691892  1 0.0075 98167 | 0/329
291 h-m-p  0.0023 0.3438   3.2597 +YC   212710.391870  1 0.0077 98501 | 0/329
292 h-m-p  0.0021 0.0863  11.9463 CC    212709.464969  1 0.0032 98835 | 0/329
293 h-m-p  0.0016 0.0485  24.0811 CC    212708.235829  1 0.0019 99169 | 0/329
294 h-m-p  0.0021 0.0579  22.2471 YC    212708.032329  1 0.0008 99502 | 0/329
295 h-m-p  0.0027 0.0745   6.8532 C     212708.014326  0 0.0008 99834 | 0/329
296 h-m-p  0.0035 0.5826   1.5263 Y     212708.010849  0 0.0015 100166 | 0/329
297 h-m-p  0.0031 0.6399   0.7512 YC    212707.992208  1 0.0072 100499 | 0/329
298 h-m-p  0.0024 0.3200   2.2852 +CC   212707.781038  1 0.0085 101163 | 0/329
299 h-m-p  0.0020 0.0696   9.8681 +YC   212706.558161  1 0.0050 101497 | 0/329
300 h-m-p  0.0016 0.0154  30.4428 CC    212704.810809  1 0.0019 101831 | 0/329
301 h-m-p  0.0021 0.0350  28.0379 YC    212704.355434  1 0.0011 102164 | 0/329
302 h-m-p  0.0027 0.0752  11.3738 C     212704.307493  0 0.0008 102496 | 0/329
303 h-m-p  0.0033 0.2587   2.7547 C     212704.302597  0 0.0010 102828 | 0/329
304 h-m-p  0.0027 0.9269   0.9903 C     212704.293370  0 0.0038 103160 | 0/329
305 h-m-p  0.0033 1.1561   1.1477 +C    212704.140943  0 0.0137 103822 | 0/329
306 h-m-p  0.0024 0.1221   6.4793 +CC   212702.448340  1 0.0087 104157 | 0/329
307 h-m-p  0.0015 0.0166  36.6673 CC    212700.201207  1 0.0017 104491 | 0/329
308 h-m-p  0.0021 0.0337  28.8902 YC    212699.732574  1 0.0010 104824 | 0/329
309 h-m-p  0.0030 0.0680   9.8914 C     212699.691144  0 0.0009 105156 | 0/329
310 h-m-p  0.0035 0.2871   2.4998 C     212699.685371  0 0.0013 105488 | 0/329
311 h-m-p  0.0041 1.4038   0.7717 YC    212699.663195  1 0.0077 105821 | 0/329
312 h-m-p  0.0029 0.4578   2.0149 +C    212699.323783  0 0.0120 106483 | 0/329
313 h-m-p  0.0026 0.0634   9.2224 +YC   212696.511829  1 0.0074 106817 | 0/329
314 h-m-p  0.0014 0.0117  48.3632 CC    212694.221479  1 0.0012 107151 | 0/329
315 h-m-p  0.0027 0.0373  21.9068 CC    212694.009113  1 0.0009 107485 | 0/329
316 h-m-p  0.0040 0.2247   4.7411 Y     212693.999451  0 0.0008 107817 | 0/329
317 h-m-p  0.0036 0.5068   1.0537 C     212693.992762  0 0.0031 108149 | 0/329
318 h-m-p  0.0037 0.9194   0.8827 +C    212693.897413  0 0.0135 108482 | 0/329
319 h-m-p  0.0026 0.1423   4.5613 +CC   212692.629617  1 0.0099 109146 | 0/329
320 h-m-p  0.0015 0.0279  30.5779 CC    212690.694705  1 0.0018 109480 | 0/329
321 h-m-p  0.0026 0.0389  21.2309 CC    212690.515090  1 0.0008 109814 | 0/329
322 h-m-p  0.0042 0.1902   3.9412 C     212690.507594  0 0.0009 110146 | 0/329
323 h-m-p  0.0039 1.0041   0.8699 C     212690.502611  0 0.0032 110478 | 0/329
324 h-m-p  0.0039 1.3822   0.7077 +C    212690.406987  0 0.0179 111140 | 0/329
325 h-m-p  0.0027 0.2929   4.7573 +CC   212688.691684  1 0.0143 111804 | 0/329
326 h-m-p  0.0014 0.0189  47.6548 CC    212686.514607  1 0.0017 112138 | 0/329
327 h-m-p  0.0037 0.0355  21.1650 CC    212686.339329  1 0.0008 112472 | 0/329
328 h-m-p  0.0042 0.2894   4.0384 C     212686.331131  0 0.0009 112804 | 0/329
329 h-m-p  0.0034 0.7214   1.0526 C     212686.323627  0 0.0033 113136 | 0/329
330 h-m-p  0.0039 0.7517   0.8734 +C    212686.194010  0 0.0161 113469 | 0/329
331 h-m-p  0.0023 0.2151   6.1735 +CC   212683.819129  1 0.0133 114133 | 0/329
332 h-m-p  0.0017 0.0234  49.0603 CC    212681.435850  1 0.0016 114467 | 0/329
333 h-m-p  0.0029 0.0229  26.9670 C     212681.179754  0 0.0008 114799 | 0/329
334 h-m-p  0.0049 0.1863   4.1168 Y     212681.170400  0 0.0009 115131 | 0/329
335 h-m-p  0.0041 1.3034   0.9315 C     212681.157745  0 0.0049 115463 | 0/329
336 h-m-p  0.0048 1.0941   0.9368 +CC   212680.826339  1 0.0240 116127 | 0/329
337 h-m-p  0.0022 0.0786  10.0321 +CC   212677.514397  1 0.0079 116791 | 0/329
338 h-m-p  0.0017 0.0214  47.1141 YC    212675.967098  1 0.0011 117124 | 0/329
339 h-m-p  0.0045 0.0517  11.9630 YC    212675.914878  1 0.0007 117457 | 0/329
340 h-m-p  0.0043 0.5282   2.0293 C     212675.909465  0 0.0015 117789 | 0/329
341 h-m-p  0.0059 1.3125   0.5041 +C    212675.841733  0 0.0207 118122 | 0/329
342 h-m-p  0.0048 0.4015   2.1846 +CC   212673.319819  1 0.0303 118786 | 0/329
343 h-m-p  0.0015 0.0180  43.5708 CC    212670.310128  1 0.0016 119120 | 0/329
344 h-m-p  0.0035 0.0532  20.2257 C     212670.131859  0 0.0009 119452 | 0/329
345 h-m-p  0.0038 0.2587   4.4997 C     212670.120823  0 0.0009 119784 | 0/329
346 h-m-p  0.0056 1.1165   0.7576 C     212670.103436  0 0.0066 120116 | 0/329
347 h-m-p  0.0039 0.9788   1.2842 +CC   212669.572774  1 0.0236 120780 | 0/329
348 h-m-p  0.0020 0.0588  15.1923 +CC   212665.103968  1 0.0075 121115 | 0/329
349 h-m-p  0.0025 0.0273  46.4419 YC    212663.917188  1 0.0011 121448 | 0/329
350 h-m-p  0.0043 0.0610  11.2822 YC    212663.866275  1 0.0008 121781 | 0/329
351 h-m-p  0.0060 0.3886   1.5015 C     212663.858342  0 0.0024 122113 | 0/329
352 h-m-p  0.0050 1.0768   0.7135 +C    212663.715396  0 0.0206 122446 | 0/329
353 h-m-p  0.0040 0.1980   3.6391 +CC   212659.837134  1 0.0209 123110 | 0/329
354 h-m-p  0.0012 0.0133  63.6105 C     212656.254412  0 0.0012 123442 | 0/329
355 h-m-p  0.0083 0.0977   9.1704 -YC   212656.212033  1 0.0010 123776 | 0/329
356 h-m-p  0.0191 1.2540   0.4576 C     212656.158205  0 0.0198 124108 | 0/329
357 h-m-p  0.0042 0.8185   2.1864 +YC   212653.735206  1 0.0352 124771 | 0/329
358 h-m-p  0.0014 0.0307  55.3776 CC    212649.348763  1 0.0021 125105 | 0/329
359 h-m-p  0.0128 0.0749   9.1885 -C    212649.308096  0 0.0009 125438 | 0/329
360 h-m-p  0.1037 8.0000   0.0812 +CC   212647.696631  1 0.6526 125773 | 0/329
361 h-m-p  0.0019 0.0267  27.3662 YC    212642.884700  1 0.0034 126435 | 0/329
362 h-m-p  0.0224 0.2173   4.1211 -Y    212642.872346  0 0.0011 126768 | 0/329
363 h-m-p  0.0594 8.0000   0.0771 ++YC  212636.305475  1 1.9588 127103 | 0/329
364 h-m-p  1.6000 8.0000   0.0474 YC    212629.249104  1 2.9261 127765 | 0/329
365 h-m-p  1.6000 8.0000   0.0529 CC    212624.962303  1 2.0916 128428 | 0/329
366 h-m-p  1.6000 8.0000   0.0326 CC    212622.446145  1 2.4707 129091 | 0/329
367 h-m-p  1.6000 8.0000   0.0228 YC    212619.872056  1 3.3205 129753 | 0/329
368 h-m-p  1.6000 8.0000   0.0240 YC    212617.485978  1 2.7730 130415 | 0/329
369 h-m-p  1.6000 8.0000   0.0214 YC    212615.260126  1 3.5803 131077 | 0/329
370 h-m-p  1.6000 8.0000   0.0250 YC    212612.446516  1 3.5585 131739 | 0/329
371 h-m-p  1.6000 8.0000   0.0266 YC    212609.934988  1 2.8927 132401 | 0/329
372 h-m-p  1.6000 8.0000   0.0247 YC    212607.667296  1 3.4130 133063 | 0/329
373 h-m-p  1.6000 8.0000   0.0230 YC    212605.209758  1 3.1895 133725 | 0/329
374 h-m-p  1.6000 8.0000   0.0246 YC    212603.419236  1 2.6039 134387 | 0/329
375 h-m-p  1.6000 8.0000   0.0279 YC    212602.065665  1 2.9431 135049 | 0/329
376 h-m-p  1.6000 8.0000   0.0170 YC    212600.523752  1 3.2055 135711 | 0/329
377 h-m-p  1.6000 8.0000   0.0177 YC    212599.330325  1 2.7602 136373 | 0/329
378 h-m-p  1.6000 8.0000   0.0161 YC    212598.265353  1 3.0671 137035 | 0/329
379 h-m-p  1.6000 8.0000   0.0154 YC    212596.948870  1 3.5665 137697 | 0/329
380 h-m-p  1.6000 8.0000   0.0167 YC    212595.313928  1 3.5701 138359 | 0/329
381 h-m-p  1.6000 8.0000   0.0221 YC    212593.364316  1 3.2194 139021 | 0/329
382 h-m-p  1.6000 8.0000   0.0251 CC    212592.334211  1 2.3352 139684 | 0/329
383 h-m-p  1.6000 8.0000   0.0230 CC    212591.707014  1 2.2194 140347 | 0/329
384 h-m-p  1.6000 8.0000   0.0136 YC    212591.188441  1 2.6089 141009 | 0/329
385 h-m-p  1.6000 8.0000   0.0110 +YC   212590.141745  1 4.0945 141672 | 0/329
386 h-m-p  1.6000 8.0000   0.0171 YC    212588.941978  1 3.1017 142334 | 0/329
387 h-m-p  1.6000 8.0000   0.0169 YC    212587.574126  1 3.7200 142996 | 0/329
388 h-m-p  1.6000 8.0000   0.0149 +YC   212584.821769  1 5.0986 143659 | 0/329
389 h-m-p  1.6000 8.0000   0.0223 +YC   212579.978609  1 4.0279 144322 | 0/329
390 h-m-p  1.6000 8.0000   0.0403 YC    212573.160988  1 3.2781 144984 | 0/329
391 h-m-p  1.6000 8.0000   0.0433 CCC   212567.242117  2 2.4836 145649 | 0/329
392 h-m-p  1.6000 8.0000   0.0319 CCC   212563.110767  2 2.3893 146314 | 0/329
393 h-m-p  1.6000 8.0000   0.0438 CC    212560.590371  1 1.8383 146977 | 0/329
394 h-m-p  1.6000 8.0000   0.0316 CCC   212558.326597  2 1.7125 147642 | 0/329
395 h-m-p  1.6000 8.0000   0.0211 CC    212557.177183  1 2.1554 148305 | 0/329
396 h-m-p  1.6000 8.0000   0.0141 YC    212556.209744  1 3.2370 148967 | 0/329
397 h-m-p  1.6000 8.0000   0.0132 CC    212555.738566  1 2.1307 149630 | 0/329
398 h-m-p  1.6000 8.0000   0.0081 YC    212555.452003  1 2.9385 150292 | 0/329
399 h-m-p  1.6000 8.0000   0.0071 YC    212555.080571  1 3.9628 150954 | 0/329
400 h-m-p  1.6000 8.0000   0.0116 YC    212554.727406  1 2.7834 151616 | 0/329
401 h-m-p  1.6000 8.0000   0.0080 YC    212554.525947  1 2.7379 152278 | 0/329
402 h-m-p  1.6000 8.0000   0.0081 CC    212554.394393  1 2.5168 152941 | 0/329
403 h-m-p  1.6000 8.0000   0.0051 CC    212554.333967  1 2.2289 153604 | 0/329
404 h-m-p  1.6000 8.0000   0.0041 CC    212554.298038  1 2.4928 154267 | 0/329
405 h-m-p  1.6000 8.0000   0.0020 CC    212554.278394  1 2.5080 154930 | 0/329
406 h-m-p  1.6000 8.0000   0.0016 YC    212554.257842  1 3.6327 155592 | 0/329
407 h-m-p  1.6000 8.0000   0.0019 C     212554.245894  0 2.4761 156253 | 0/329
408 h-m-p  1.6000 8.0000   0.0013 YC    212554.235048  1 3.4946 156915 | 0/329
409 h-m-p  1.6000 8.0000   0.0015 C     212554.227269  0 2.4347 157576 | 0/329
410 h-m-p  1.6000 8.0000   0.0010 C     212554.223695  0 2.3987 158237 | 0/329
411 h-m-p  1.6000 8.0000   0.0008 C     212554.222141  0 2.2174 158898 | 0/329
412 h-m-p  1.6000 8.0000   0.0004 Y     212554.220936  0 3.5271 159559 | 0/329
413 h-m-p  1.6000 8.0000   0.0005 Y     212554.219917  0 2.7585 160220 | 0/329
414 h-m-p  1.6000 8.0000   0.0003 Y     212554.219248  0 2.7770 160881 | 0/329
415 h-m-p  1.6000 8.0000   0.0003 C     212554.218928  0 2.3388 161542 | 0/329
416 h-m-p  1.6000 8.0000   0.0002 C     212554.218812  0 2.0145 162203 | 0/329
417 h-m-p  1.6000 8.0000   0.0001 C     212554.218782  0 2.0528 162864 | 0/329
418 h-m-p  1.6000 8.0000   0.0001 C     212554.218775  0 1.8025 163525 | 0/329
419 h-m-p  1.6000 8.0000   0.0000 Y     212554.218772  0 2.6344 164186 | 0/329
420 h-m-p  1.6000 8.0000   0.0000 Y     212554.218770  0 3.8387 164847 | 0/329
421 h-m-p  1.6000 8.0000   0.0000 Y     212554.218766  0 3.7261 165508 | 0/329
422 h-m-p  1.6000 8.0000   0.0000 +Y    212554.218760  0 4.7599 166170 | 0/329
423 h-m-p  1.6000 8.0000   0.0000 C     212554.218756  0 2.1762 166831 | 0/329
424 h-m-p  1.6000 8.0000   0.0000 C     212554.218755  0 1.9709 167492 | 0/329
425 h-m-p  1.6000 8.0000   0.0000 C     212554.218755  0 1.9852 168153 | 0/329
426 h-m-p  1.6000 8.0000   0.0000 C     212554.218755  0 1.6000 168814 | 0/329
427 h-m-p  1.6000 8.0000   0.0000 C     212554.218755  0 1.8308 169475 | 0/329
428 h-m-p  1.4636 8.0000   0.0000 Y     212554.218755  0 2.8857 170136 | 0/329
429 h-m-p  1.6000 8.0000   0.0000 ---Y  212554.218755  0 0.0063 170800
Out..
lnL  = -212554.218755
170801 lfun, 170801 eigenQcodon, 55851927 P(t)
end of tree file.

Time used: 59:24:36
