Supplemental results for CODEML (seqf: eukaryote_if2_codon_alignment.phy  treef: eukaryote_if2_codon_alignment.fasta.treefile)

